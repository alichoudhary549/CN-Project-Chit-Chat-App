import 'package:flutter/material.dart';
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

const String agoraAppId = '9b2e2d28cc50477886e53460039527a5'; // Your Agora App ID

class CallScreen extends StatefulWidget {
  final String channelName;
  final String? token;
  final bool isVideo;
  final String contactName;
  final String contactAvatar;
  final String? callDocId;
  final String? contactId;

  const CallScreen({
    super.key,
    required this.channelName,
    this.token,
    required this.isVideo,
    required this.contactName,
    required this.contactAvatar,
    this.callDocId,
    this.contactId,
  });

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  int? _remoteUid;
  late RtcEngine _engine;
  bool _joined = false;
  bool _muted = false;
  bool _videoEnabled = true;
  final AudioPlayer _ringtonePlayer = AudioPlayer();
  bool _isCaller = true;
  bool _isEngineInitialized = false;

  @override
  void initState() {
    super.initState();
    _initAgora();
    _determineCallRoleAndPlayRingtone();
  }

  Future<void> _determineCallRoleAndPlayRingtone() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null || widget.callDocId == null) {
      return;
    }

    try {
      final callDoc = await FirebaseFirestore.instance
          .collection('calls')
          .doc(widget.callDocId)
          .get();

      if (callDoc.exists) {
        final data = callDoc.data();
        if (data != null) {
          _isCaller = data['callerId'] == currentUser.uid;
          if (_isCaller) {
            await _ringtonePlayer.setReleaseMode(ReleaseMode.loop);
            await _ringtonePlayer.play(AssetSource('sounds/outgoing_call.mp3'));
          } else {
            if (data['status'] == 'ringing') {
              await _ringtonePlayer.setReleaseMode(ReleaseMode.loop);
              await _ringtonePlayer.play(AssetSource('sounds/incoming_call.mp3'));
            }
          }
        }
      }
    } catch (e) {
      // Removed print statements:
      // print('Error determining call role or playing ringtone: $e');
    }
  }

  Future<void> _initAgora() async {
    // Request permissions
    final cameraStatus = await Permission.camera.request();
    final microphoneStatus = await Permission.microphone.request();

    if (cameraStatus.isGranted && microphoneStatus.isGranted) {
      // Removed print statements:
      // print('Camera and Microphone permissions granted.');
      _engine = createAgoraRtcEngine();
      try {
        await _engine.initialize(RtcEngineContext(appId: agoraAppId));
        _isEngineInitialized = true;

        if (widget.isVideo) {
          await _engine.enableVideo();
        } else {
          await _engine.disableVideo();
        }

        _engine.registerEventHandler(
          RtcEngineEventHandler(
            onJoinChannelSuccess: (connection, elapsed) {
              setState(() => _joined = true);
              _ringtonePlayer.stop();
              _updateCallStatus('connected');
            },
            onUserJoined: (connection, remoteUid, elapsed) {
              setState(() => _remoteUid = remoteUid);
              _ringtonePlayer.stop();
              _updateCallStatus('connected');
            },
            onUserOffline: (connection, remoteUid, reason) {
              setState(() => _remoteUid = null);
              _updateCallStatus('ended');
              if (mounted) Navigator.pop(context);
            },
            onLeaveChannel: (connection, stats) {
              setState(() {
                _joined = false;
                _remoteUid = null;
              });
              _ringtonePlayer.stop();
              _updateCallStatus('ended');
              if (mounted) Navigator.pop(context);
            },
            onError: (err, msg) {
              if (mounted) Navigator.pop(context);
            },
          ),
        );

        final token = widget.token ?? '';
        if (token.isEmpty) {
          print('Warning: Agora token is empty. If your project requires tokens, implement token generation and passing.');
          // You might want to show a user-facing message here as well
        }

        print('Attempting to join channel: ${widget.channelName} with token: $token');

        await _engine.joinChannel(
          token: token, // Use the determined token (or empty string)
          channelId: widget.channelName, // Use the provided channel name
          uid: 0, // Use 0 to let Agora assign a UID
          options: const ChannelMediaOptions(),
        );
        print('joinChannel called.');
      } catch (e) {
        // Catch any errors during initialization or joining
        print('Agora initialization/joining error: ${e.toString()}'); // Log the exception
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Call failed: Initialization or joining error.')),
        );
        _ringtonePlayer.stop();
        _updateCallStatus('failed');
        if (mounted) Navigator.pop(context);
      }
    } else {
      // Handle permissions not granted
      print('Permissions not granted. Cannot start call.'); // Log permission denial
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Camera and microphone permissions are required for calls.')),
        );
        _updateCallStatus('cancelled'); // Mark as cancelled if permissions not granted
        if (mounted) Navigator.pop(context); // Navigate back if permissions not granted
      }
    }
  }

  // Add a helper function to update call status in Firestore
  Future<void> _updateCallStatus(String status) async {
    if (widget.callDocId == null) return; // Cannot update if no call document ID
    try {
      await FirebaseFirestore.instance
          .collection('calls')
          .doc(widget.callDocId)
          .update({'status': status});
      // Removed print statements:
      // print('Call status updated to: $status for docId: ${widget.callDocId}');
    } catch (e) {
      // Removed print statements:
      // print('Error updating call status: $e');
    }
  }

  @override
  void dispose() {
    // Only leave and release the engine if it was initialized
    if (_isEngineInitialized) { // Check the _isEngineInitialized flag
      _engine.leaveChannel();
      _engine.release();
    }
    _ringtonePlayer.stop();
    _ringtonePlayer.dispose();
    // Consider updating call status to 'ended' if it's not already
    // This might be needed if the screen is disposed without a formal leaveChannel event
    // However, be careful not to overwrite a 'missed' or 'failed' status
    // A more robust solution might involve listening to the call document stream
    super.dispose();
  }

  void _onToggleMute() {
    setState(() => _muted = !_muted);
    _engine.muteLocalAudioStream(_muted);
  }

  void _onSwitchCamera() {
    _engine.switchCamera();
  }

  void _onToggleVideo() {
    setState(() => _videoEnabled = !_videoEnabled);
    _engine.muteLocalVideoStream(!_videoEnabled);
  }

  Widget _renderLocalPreview() {
    // Removed print statements:
    // print('_renderLocalPreview called. _joined: $_joined, isVideo: ${widget.isVideo}');
    if (!_joined) {
      return const Center(child: CircularProgressIndicator());
    }
    if (widget.isVideo) {
       // Removed print statements:
       // print('Rendering local video preview.');
      return AgoraVideoView(
        controller: VideoViewController(
          rtcEngine: _engine,
          canvas: const VideoCanvas(uid: 0),
        ),
      );
    } else {
       // Removed print statements:
       // print('Rendering local audio preview.');
      return const Center(child: Icon(Icons.mic, size: 80, color: Colors.green));
    }
  }

  Widget _renderRemoteVideo() {
    if (_remoteUid != null && widget.isVideo) {
      return AgoraVideoView(
        controller: VideoViewController.remote(
          rtcEngine: _engine,
          canvas: VideoCanvas(uid: _remoteUid),
          connection: RtcConnection(channelId: widget.channelName),
        ),
      );
    } else if (_remoteUid != null && !widget.isVideo) {
      return const Center(child: Icon(Icons.mic, size: 80, color: Colors.blue));
    } else {
      return const Center(child: Text('Waiting for user to join...'));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: _joined
            ? widget.isVideo
                ? Stack(
                    children: [
                      // Remote User Video
                      _renderRemoteVideo(),
                      // Local User Video (as an overlay)
                      Positioned(
                        top: 40,
                        right: 20,
                        child: SizedBox(
                          width: 100,
                          height: 150,
                          child: _renderLocalPreview(),
                        ),
                      ),
                      // Call Controls Overlay
                      _buildVideoCallControls(),
                    ],
                  )
                : _buildAudioCallUI() // Audio call UI
            : _buildConnectingUI(), // Connecting state UI
      ),
    );
  }

  Widget _buildConnectingUI() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        CircleAvatar(
          radius: 60,
          backgroundImage: widget.contactAvatar.isNotEmpty ? NetworkImage(widget.contactAvatar) : null,
          child: widget.contactAvatar.isEmpty ? Icon(Icons.person, size: 60, color: Colors.grey) : null,
        ),
        const SizedBox(height: 20),
        Text(
          'Calling ${widget.contactName}...',
          style: const TextStyle(fontSize: 20, color: Colors.white),
        ),
        const SizedBox(height: 20),
        CircularProgressIndicator(color: Theme.of(context).primaryColor),
         const SizedBox(height: 40),
         IconButton(
           icon: const Icon(Icons.call_end, size: 40, color: Colors.red),
           onPressed: _leaveChannel,
         ),
      ],
    );
  }

  Widget _buildAudioCallUI() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        CircleAvatar(
          radius: 60,
          backgroundImage: widget.contactAvatar.isNotEmpty ? NetworkImage(widget.contactAvatar) : null,
          child: widget.contactAvatar.isEmpty ? Icon(Icons.person, size: 60, color: Colors.grey) : null,
        ),
        const SizedBox(height: 20),
        Text(
          'In call with ${widget.contactName}',
          style: const TextStyle(fontSize: 20, color: Colors.white),
        ),
        const SizedBox(height: 40),
        // Audio Call Controls
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            IconButton(
              icon: Icon(_muted ? Icons.mic_off : Icons.mic, size: 40, color: Colors.white),
              onPressed: _onToggleMute,
            ),
            IconButton(
              icon: const Icon(Icons.call_end, size: 40, color: Colors.red),
              onPressed: _leaveChannel,
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildVideoCallControls() {
     return Positioned(
       bottom: 40,
       left: 0,
       right: 0,
       child: Row(
         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
         children: [
           IconButton(
             icon: Icon(_muted ? Icons.mic_off : Icons.mic, size: 40, color: Colors.white),
             onPressed: _onToggleMute,
           ),
            IconButton(
             icon: Icon(_videoEnabled ? Icons.videocam : Icons.videocam_off, size: 40, color: Colors.white),
             onPressed: _onToggleVideo,
           ),
           IconButton(
             icon: const Icon(Icons.switch_camera, size: 40, color: Colors.white),
             onPressed: _onSwitchCamera,
           ),
           IconButton(
             icon: const Icon(Icons.call_end, size: 40, color: Colors.red),
             onPressed: _leaveChannel,
           ),
         ],
       ),
     );
  }

  void _leaveChannel() async {
    // Update call status to ended before leaving the channel
    await _updateCallStatus('ended');
    await _engine.leaveChannel();
     // Navigator.pop(context); // Navigating back handled by onLeaveChannel event
  }
} 