import 'dart:io';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_chat_ui/flutter_chat_ui.dart';
import 'package:flutter_chat_types/flutter_chat_types.dart' as types;
import 'package:image_picker/image_picker.dart';
import 'package:cloudinary_public/cloudinary_public.dart';
import 'dart:async';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'dart:typed_data';
import 'call_screen.dart';
import 'package:audioplayers/audioplayers.dart';
import '../widgets/avatar_widget.dart';
import 'contact_info_screen.dart';
import '../widgets/video_player_widget.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

class ChatRoomScreen extends StatefulWidget {
  final String chatId;
  final String contactName;
  final String contactId;
  final String? contactAvatar;

  const ChatRoomScreen({
    super.key,
    required this.chatId,
    required this.contactName,
    required this.contactId,
    this.contactAvatar,
  });

  static String getChatId(String userId1, String userId2) {
    final ids = [userId1, userId2]..sort();
    return 'chat_${ids[0]}_${ids[1]}';
  }

  @override
  State<ChatRoomScreen> createState() => _ChatRoomScreenState();
}

class _ChatRoomScreenState extends State<ChatRoomScreen> {

  final FocusNode _focusNode = FocusNode();
  final TextEditingController _textController = TextEditingController();
  bool _isLoading = false;
  bool _isTyping = false;
  final _imagePicker = ImagePicker();
  final cloudinary = CloudinaryPublic('dkuyjynpe', 'statuses', cache: false);

  late final types.User _user;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _incomingCallSub;
  final AudioPlayer _ringtonePlayer = AudioPlayer();

  // Temporary token and channel for testing (replace with dynamic token generation in production)
   String tempAgoraToken = '007eJxTYEgr7dt8TFSkoqJk3pt11c+XqnfpTZl48au50Y+527gSLBIVGCyTjFKNUowskpNNDUzMzS0szFJNjU3MDAyMLU2NzBNNawPNMxoCGRlqdFtZGRkYGViAGMRnApPMYJIFTPIyJGdkliRnJJbEJyfm5DAwAACzcyRm';
   String tempChannelName = 'chitchat_call';

  @override
  void initState() {
    super.initState();
    _user = types.User(
      id: FirebaseAuth.instance.currentUser?.uid ?? 'user1',
      firstName: FirebaseAuth.instance.currentUser?.displayName?.split(' ').first ?? '',
      lastName: FirebaseAuth.instance.currentUser?.displayName?.split(' ').last ?? '',
    );
    _setupTypingListener();
    _listenForNewIncomingCalls();
    _resetUnreadCount();
    _setupFcm();
  }

  void _setupTypingListener() {
    FirebaseFirestore.instance
        .collection('chats')
        .doc(widget.chatId)
        .snapshots()
        .listen((snapshot) {
      if (snapshot.exists) {
        final data = snapshot.data() as Map<String, dynamic>;
        final typingStatus = data['typing'];
        if (typingStatus is String) {
           setState(() {
             _isTyping = typingStatus == widget.contactId;
           });
        } else {
           setState(() {
             _isTyping = false;
           });
        }
      }
    });
  }

  @override
  void dispose() {
    _incomingCallSub?.cancel();
    _ringtonePlayer.stop();
    _ringtonePlayer.dispose();
    _focusNode.dispose();
    _textController.dispose();
    super.dispose();
  }

  types.Status? _getMessageStatus(String? status) {
    switch (status) {
      case 'sending':
        return types.Status.sending;
      case 'sent':
        return types.Status.sent;
      case 'delivered':
        return types.Status.delivered;
      case 'seen':
        return types.Status.seen;
      default:
        return null;
    }
  }

  Future<void> _markMessagesAsRead() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    try {
      // First get messages that are not from the current user
      final unreadMessages = await FirebaseFirestore.instance
          .collection('chats')
          .doc(widget.chatId)
          .collection('messages')
          .where('authorId', isNotEqualTo: user.uid)
          .where('status', isEqualTo: 'sent')  // Only get messages that are sent but not seen
          .get();

      if (unreadMessages.docs.isNotEmpty) {
        final batch = FirebaseFirestore.instance.batch();
        for (var doc in unreadMessages.docs) {
          batch.update(doc.reference, {'status': 'seen'});
        }
        await batch.commit();
      }
    } catch (e) {
      print('Error marking messages as read: $e');
    }
  }

  void _handleTyping(String text) {
    FirebaseFirestore.instance
        .collection('chats')
        .doc(widget.chatId)
        .set({'typing': _user.id}, SetOptions(merge: true));
  }

  Future<void> _handleImageSelection() async {
    final result = await _imagePicker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 70,
    );

    if (result != null) {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final nonNullableResult = result;

      try {
        String imageUrl;
        int size;
        if (kIsWeb) {
          Uint8List bytes = await nonNullableResult.readAsBytes();
          size = bytes.length;
          final response = await cloudinary.uploadFile(
            CloudinaryFile.fromBytesData(
              bytes,
              resourceType: CloudinaryResourceType.Image,
              folder: 'chat_images',
              identifier: nonNullableResult.name,
            ),
          );
          imageUrl = response.secureUrl;
        } else {
          final file = File(nonNullableResult.path);
          size = file.lengthSync();
          final response = await cloudinary.uploadFile(
            CloudinaryFile.fromFile(
              file.path,
              resourceType: CloudinaryResourceType.Image,
              folder: 'chat_images',
              identifier: nonNullableResult.name,
            ),
          );
          imageUrl = response.secureUrl;
        }

        if (imageUrl.isEmpty) {
          throw Exception('Image upload failed: No URL returned');
        }

        await FirebaseFirestore.instance
            .collection('chats')
            .doc(widget.chatId)
            .collection('messages')
            .add({
          'authorId': _user.id,
          'createdAt': Timestamp.fromDate(DateTime.now()),
          'type': 'image',
          'uri': imageUrl,
          'name': nonNullableResult.name ?? 'Image',
          'size': size,
          'status': 'sent',
        });

        _updateChatMetadata('📷 Image');
      } catch (e, stack) {
        print('Image upload error: $e');
        print(stack);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Image upload failed: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  Future<void> _handleFileSelection() async {
    final result = await _imagePicker.pickMedia();
    if (result != null) {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final nonNullableResult = result;

      try {
        String fileUrl;
        int size;
        if (kIsWeb) {
          Uint8List bytes = await nonNullableResult.readAsBytes();
          size = bytes.length;
          final response = await cloudinary.uploadFile(
            CloudinaryFile.fromBytesData(
              bytes,
              resourceType: CloudinaryResourceType.Auto,
              folder: 'chat_files',
              identifier: nonNullableResult.name,
            ),
          );
          fileUrl = response.secureUrl;
        } else {
          final file = File(nonNullableResult.path);
          size = file.lengthSync();
          final response = await cloudinary.uploadFile(
            CloudinaryFile.fromFile(
              file.path,
              resourceType: CloudinaryResourceType.Auto,
              folder: 'chat_files',
              identifier: nonNullableResult.name,
            ),
          );
          fileUrl = response.secureUrl;
        }

        await FirebaseFirestore.instance
            .collection('chats')
            .doc(widget.chatId)
            .collection('messages')
            .add({
          'authorId': _user.id,
          'createdAt': Timestamp.fromDate(DateTime.now()),
          'type': 'file',
          'uri': fileUrl,
          'name': nonNullableResult.name,
          'size': size,
          'status': 'sent',
        });

        _updateChatMetadata('📎 File');
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('File upload failed: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  Future<void> _handleVoiceRecording() async {
    if (_isTyping) {
      setState(() => _isTyping = false);
    } else {
      setState(() => _isTyping = true);
    }
  }

  Future<void> _resetUnreadCount() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    final chatRef = FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .collection('chats')
        .doc(widget.chatId);
    await chatRef.set({'unreadCount': 0}, SetOptions(merge: true));
  }

  Future<void> _updateChatMetadata(String lastMessage) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final batch = FirebaseFirestore.instance.batch();
    final senderChatRef = FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .collection('chats')
        .doc(widget.chatId);
    final receiverChatRef = FirebaseFirestore.instance
        .collection('users')
        .doc(widget.contactId)
        .collection('chats')
        .doc(widget.chatId);

    // Get sender info
    final senderUserDoc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
    final senderData = senderUserDoc.data() ?? {};
    final senderFirstName = senderData['firstName'] ?? '';
    final senderLastName = senderData['lastName'] ?? '';
    final senderDisplayName = [senderFirstName, senderLastName].where((s) => s.isNotEmpty).join(' ').trim();
    final senderFallbackName = senderData['name'] ?? '';
    final senderEmail = senderData['email'] ?? '';
    final senderNameToShow = senderDisplayName.isNotEmpty
        ? senderDisplayName
        : (senderFallbackName.isNotEmpty ? senderFallbackName : (senderEmail.isNotEmpty ? senderEmail : 'Unknown'));
    final senderAvatar = senderData['avatar'] ?? '';

    // Get receiver info (for fallback contact name)
    final receiverUserDoc = await FirebaseFirestore.instance.collection('users').doc(widget.contactId).get();
    final receiverData = receiverUserDoc.data() ?? {};
    final receiverFirstName = receiverData['firstName'] ?? '';
    final receiverLastName = receiverData['lastName'] ?? '';
    final receiverDisplayName = [receiverFirstName, receiverLastName].where((s) => s.isNotEmpty).join(' ').trim();
    final receiverFallbackName = receiverData['name'] ?? '';
    final receiverEmail = receiverData['email'] ?? '';
    final receiverNameToShow = receiverDisplayName.isNotEmpty
        ? receiverDisplayName
        : (receiverFallbackName.isNotEmpty ? receiverFallbackName : (receiverEmail.isNotEmpty ? receiverEmail : 'Unknown'));
    final receiverAvatar = receiverData['avatar'] ?? '';

    // Sender's chat doc
    batch.set(senderChatRef, {
      'contactId': widget.contactId,
      'contactName': receiverNameToShow,
      'firstName': receiverFirstName,
      'lastName': receiverLastName,
      'contactAvatar': receiverAvatar,
      'lastMessage': lastMessage,
      'timestamp': Timestamp.fromDate(DateTime.now()),
      'unreadCount': 0,
    }, SetOptions(merge: true));

    // Receiver's chat doc
    batch.set(receiverChatRef, {
      'contactId': user.uid,
      'contactName': senderNameToShow,
      'firstName': senderFirstName,
      'lastName': senderLastName,
      'contactAvatar': senderAvatar,
      'lastMessage': lastMessage,
      'timestamp': Timestamp.fromDate(DateTime.now()),
      'unreadCount': FieldValue.increment(1),
    }, SetOptions(merge: true));

    await batch.commit();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: _buildAppBar(),
      body: GestureDetector(
        onTap: () => _focusNode.unfocus(),
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.white, Color(0xFFF9F5FF)],
            ),
          ),
          child: Column(
            children: [
              if (_isTyping)
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  color: Colors.grey.shade100,
                  child: Text(
                    '${widget.contactName} is typing...',
                    style: TextStyle(
                      color: Colors.grey.shade600,
                      fontStyle: FontStyle.italic,
                      fontFamily: 'Poppins',
                    ),
                  ),
                ),
              Expanded(
                child: Container(
                  child: _isLoading
                      ? const Center(
                          child: CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF6C5CE7)),
                          ),
                        )
                      : StreamBuilder<QuerySnapshot>(
                          stream: FirebaseFirestore.instance
                              .collection('chats')
                              .doc(widget.chatId)
                              .collection('messages')
                              .orderBy('createdAt', descending: true)
                              .snapshots(),
                          builder: (context, snapshot) {
                            if (snapshot.hasError) {
                              return Center(
                                child: Text(
                                  'Error loading messages',
                                  style: TextStyle(
                                    color: Colors.grey.shade600,
                                    fontFamily: 'Poppins',
                                  ),
                                ),
                              );
                            }

                            if (snapshot.hasData) {
                              _markMessagesAsRead();
                            }

                            List<types.Message> newMessages = [];
                            if (snapshot.hasData) {
                              newMessages = snapshot.data!.docs.map((doc) {
                                final data = doc.data() as Map<String, dynamic>;
                                if (data['type'] == 'text') {
                                  return types.TextMessage(
                                    id: doc.id,
                                    author: types.User(id: data['authorId'] as String),
                                    createdAt: (data['createdAt'] as Timestamp).millisecondsSinceEpoch,
                                    text: data['text'] as String,
                                    status: _getMessageStatus(data['status'] as String?),
                                  );
                                } else if (data['type'] == 'image') {
                                  return types.ImageMessage(
                                    id: doc.id,
                                    author: types.User(id: data['authorId'] as String),
                                    createdAt: (data['createdAt'] as Timestamp).millisecondsSinceEpoch,
                                    uri: data['uri'] as String,
                                    name: data['name'] ?? 'Image',
                                    size: data['size'] ?? 0,
                                    status: _getMessageStatus(data['status'] as String?),
                                  );
                                } else if (data['type'] == 'audio') {
                                  return types.AudioMessage(
                                    id: doc.id,
                                    author: types.User(id: data['authorId'] as String),
                                    createdAt: (data['createdAt'] as Timestamp).millisecondsSinceEpoch,
                                    uri: data['uri'] as String,
                                    name: data['name'] ?? 'Voice message',
                                    size: data['size'] ?? 0,
                                    status: _getMessageStatus(data['status'] as String?),
                                    duration: const Duration(seconds: 0),
                                  );
                                } else if (data['type'] == 'file') {
                                  return types.FileMessage(
                                    id: doc.id,
                                    author: types.User(id: data['authorId'] as String),
                                    createdAt: (data['createdAt'] as Timestamp).millisecondsSinceEpoch,
                                    uri: data['uri'] as String,
                                    name: data['name'] ?? 'File',
                                    size: data['size'] ?? 0,
                                    status: _getMessageStatus(data['status'] as String?),
                                  );
                                } else if (data['type'] == 'custom' && data['metadata']?['messageType'] == 'video') {
                                  return types.CustomMessage(
                                    id: doc.id,
                                    author: types.User(id: data['authorId'] as String),
                                    createdAt: (data['createdAt'] as Timestamp).millisecondsSinceEpoch,
                                    metadata: data['metadata'] as Map<String, dynamic>?,
                                    status: _getMessageStatus(data['status'] as String?),
                                    type: types.MessageType.custom,
                                  );
                                } else if (data['type'] == 'video') {
                                  return types.VideoMessage(
                                    id: doc.id,
                                    author: types.User(id: data['authorId'] as String),
                                    createdAt: (data['createdAt'] as Timestamp).millisecondsSinceEpoch,
                                    uri: data['uri'] as String,
                                    name: data['name'] ?? 'Video',
                                    size: data['size'] ?? 0,
                                    status: _getMessageStatus(data['status'] as String?),
                                  );
                                }
                                return null;
                              }).whereType<types.Message>().toList();
                            }

                            return Column(
                              children: [
                                Expanded(
                                  child: Container(
                                    child: Chat(
                                      messages: newMessages,
                                      onSendPressed: _handleSendPressed,
                                      onAttachmentPressed: _handleAttachmentPressed,
                                      user: _user,
                                      theme: _buildChatTheme(),
                                      showUserAvatars: true,
                                      showUserNames: true,
                                      inputOptions: const InputOptions(
                                        enabled: false,
                                      ),
                                      customBottomWidget: const SizedBox.shrink(),
                                      customMessageBuilder: (message, {required int messageWidth}) {
                                        print('Custom message builder called for message type: ${message.type}');
                                        if (message is types.CustomMessage && message.metadata?['messageType'] == 'video') {
                                          print('Identified custom video message.');
                                          final videoUrl = message.metadata?['uri'] as String?;
                                          if (videoUrl != null) {
                                            print('Video URL found: $videoUrl');
                                            return VideoPlayerWidget(videoUrl: videoUrl, isThumbnail: false, messageWidth: messageWidth, message: message, currentUserId: _user.id);
                                          }
                                        }
                                        print('Not a custom video message or no URL. Returning SizedBox.shrink.');
                                        return const SizedBox.shrink();
                                      },
                                      onMessageLongPress: _handleMessageLongPress,
                                    ),
                                  ),
                                ),
                                _buildCustomInput(),
                              ],
                            );
                          },
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.white,
      elevation: 0,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back, color: Colors.black),
        onPressed: () => Navigator.pop(context),
      ),
      title: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .doc(widget.contactId)
            .snapshots(),
        builder: (context, snapshot) {
          final userData = snapshot.data?.data() as Map<String, dynamic>?;
          final avatar = userData?['avatar'] as String? ?? '';
          final firstName = userData?['firstName'] as String? ?? '';
          final lastName = userData?['lastName'] as String? ?? '';
          final displayName = [firstName, lastName].where((s) => s.isNotEmpty).join(' ').trim();
          final name = displayName.isNotEmpty
              ? displayName
              : (widget.contactName.isNotEmpty ? widget.contactName : 'Unknown');
          print('DEBUG: avatar=$avatar, firstName=$firstName, lastName=$lastName, name=${name ?? 'null'}');

          return Row(
            children: [
              AvatarWidget(
                avatarUrl: avatar,
                name: name,
                radius: 20,
                showBorder: true,
                borderColor: const Color(0xFF6C5CE7),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ContactInfoScreen(
                          contactId: widget.contactId,
                          chatId: widget.chatId,
                        ),
                      ),
                    );
                  },
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        name,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                          fontFamily: 'Poppins',
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 2),
                      StreamBuilder<DocumentSnapshot>(
                        stream: FirebaseFirestore.instance
                            .collection('users')
                            .doc(widget.contactId)
                            .snapshots(),
                        builder: (context, snapshot) {
                          final data = snapshot.data?.data() as Map<String, dynamic>?;
                          final status = (data?['status'] as String?) ?? 'offline';
                          return Text(
                            status == 'online' ? 'Online' : 'Last seen recently',
                            style: TextStyle(
                              fontSize: 12,
                              color: status == 'online'
                                  ? const Color(0xFF6C5CE7)
                                  : Colors.grey.shade500,
                              fontFamily: 'Poppins',
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.videocam, color: Color(0xFF6C5CE7)),
                onPressed: () {
                  _startCall(isVideo: true);
                },
              ),
              IconButton(
                icon: const Icon(Icons.call, color: Color(0xFF6C5CE7)),
                onPressed: () {
                  _startCall(isVideo: false);
                },
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildCustomInput() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha((255 * 0.05).round()),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          IconButton(
            icon: const Icon(Icons.add, color: Color(0xFF6C5CE7), size: 24),
            padding: const EdgeInsets.all(4),
            constraints: const BoxConstraints(),
            onPressed: _handleAttachmentPressed,
          ),
          IconButton(
            icon: const Icon(Icons.camera_alt, color: Color(0xFF6C5CE7), size: 24),
            padding: const EdgeInsets.all(4),
            constraints: const BoxConstraints(),
            onPressed: _handleImageSelection,
          ),
          IconButton(
            icon: Icon(
              _isTyping ? Icons.stop : Icons.mic,
              color: const Color(0xFF6C5CE7),
              size: 24,
            ),
            padding: const EdgeInsets.all(4),
            constraints: const BoxConstraints(),
            onPressed: _handleVoiceRecording,
          ),
          Expanded(
            child: Container(
              constraints: const BoxConstraints(maxHeight: 100),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              decoration: BoxDecoration(
                color: Colors.grey.shade50,
                borderRadius: BorderRadius.circular(24),
              ),
              child: TextField(
                controller: _textController,
                focusNode: _focusNode,
                onChanged: _handleTyping,
                maxLines: null,
                textAlignVertical: TextAlignVertical.center,
                decoration: InputDecoration(
                  hintText: 'Type a message...',
                  hintStyle: TextStyle(
                    color: Colors.grey.shade500,
                    fontFamily: 'Poppins',
                    fontSize: 14,
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                ),
                style: const TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                ),
                onSubmitted: (text) {
                  final trimmed = text.trim();
                  if (trimmed.isNotEmpty) {
                    _handleSendPressed(types.PartialText(text: trimmed));
                    _textController.clear();
                  }
                },
              ),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.send, color: Color(0xFF6C5CE7), size: 24),
            padding: const EdgeInsets.all(4),
            constraints: const BoxConstraints(),
            onPressed: () {
              final text = _textController.text.trim();
              if (text.isNotEmpty) {
                _handleSendPressed(types.PartialText(text: text));
                _textController.clear();
              }
            },
          ),
        ],
      ),
    );
  }

  DefaultChatTheme _buildChatTheme() {
    return DefaultChatTheme(
      primaryColor: const Color(0xFF6C5CE7),
      secondaryColor: Colors.grey.shade100,
      inputBackgroundColor: Colors.transparent,
      inputTextColor: Colors.black,
      inputTextCursorColor: const Color(0xFF6C5CE7),
      inputBorderRadius: BorderRadius.circular(24),
      sentMessageBodyTextStyle: const TextStyle(
        color: Color.fromRGBO(255, 255, 255, 0.7),
        fontFamily: 'Poppins',
        fontSize: 14,
      ),
      receivedMessageBodyTextStyle: const TextStyle(
        color: Colors.black,
        fontFamily: 'Poppins',
        fontSize: 14,
      ),
      sentMessageCaptionTextStyle: TextStyle(
        color: const Color.fromRGBO(255, 255, 255, 0.7),
        fontFamily: 'Poppins',
        fontSize: 12,
      ),
      receivedMessageCaptionTextStyle: TextStyle(
        color: const Color.fromRGBO(0, 0, 0, 0.5),
        fontFamily: 'Poppins',
        fontSize: 12,
      ),
      sentMessageLinkTitleTextStyle: const TextStyle(
        color: Colors.white,
        fontFamily: 'Poppins',
        fontSize: 14,
      ),
      receivedMessageLinkTitleTextStyle: const TextStyle(
        color: Colors.black,
        fontFamily: 'Poppins',
        fontSize: 14,
      ),
      userAvatarNameColors: const [Color(0xFF6C5CE7)],
      attachmentButtonIcon: const Icon(Icons.attach_file, color: Color(0xFF6C5CE7), size: 24),
      sendButtonIcon: const Icon(Icons.send, color: Color(0xFF6C5CE7), size: 24),
      seenIcon: const Icon(Icons.done_all, size: 16, color: Color(0xFF6C5CE7)),
      deliveredIcon: const Icon(Icons.done_all, size: 16, color: Colors.grey),
      dateDividerTextStyle: TextStyle(
        color: Colors.grey.shade600,
        fontFamily: 'Poppins',
        fontSize: 12,
      ),
    );
  }

  Future<void> _handleSendPressed(types.PartialText message) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    try {
      await FirebaseFirestore.instance
          .collection('chats')
          .doc(widget.chatId)
          .collection('messages')
          .add({
        'authorId': _user.id,
        'createdAt': Timestamp.fromDate(DateTime.now()),
        'text': message.text,
        'type': 'text',
        'status': 'sent',
      });

      await _updateChatMetadata(message.text);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Failed to send message. Please try again.'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<String?> getUidByEmail(String email) async {
    final userSnap = await FirebaseFirestore.instance
        .collection('users')
        .where('email', isEqualTo: email)
        .get();
    return userSnap.docs.firstOrNull?.id;
  }

  Future<void> _handleAttachmentPressed() async {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.message, color: Color(0xFF6C5CE7)),
              title: const Text('Text Message'),
              onTap: () {
                Navigator.pop(context);
                _showTextMessageDialog();
              },
            ),
            ListTile(
              leading: const Icon(Icons.insert_drive_file, color: Color(0xFF6C5CE7)),
              title: const Text('Document'),
              onTap: () {
                Navigator.pop(context);
                _handleFileSelection();
              },
            ),
            ListTile(
              leading: const Icon(Icons.image, color: Color(0xFF6C5CE7)),
              title: const Text('Gallery'),
              onTap: () {
                Navigator.pop(context);
                _handleImageSelection();
              },
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Color(0xFF6C5CE7)),
              title: const Text('Camera'),
              onTap: () async {
                Navigator.pop(context);
                final result = await _imagePicker.pickImage(source: ImageSource.camera, imageQuality: 70);
                if (result != null) {
                  final user = FirebaseAuth.instance.currentUser;
                  if (user == null) return;

                  final nonNullableResult = result;

                  final file = File(nonNullableResult.path);
                  try {
                    final cloudinaryResponse = await cloudinary.uploadFile(
                      CloudinaryFile.fromFile(
                        file.path,
                        resourceType: CloudinaryResourceType.Image,
                        folder: 'chat_images',
                        identifier: nonNullableResult.name,
                      ),
                    );
                    final imageUrl = cloudinaryResponse.secureUrl;
                    if (imageUrl == null || imageUrl.isEmpty) {
                      throw Exception('Image upload failed: No URL returned');
                    }
                    await FirebaseFirestore.instance
                        .collection('chats')
                        .doc(widget.chatId)
                        .collection('messages')
                        .add({
                      'authorId': _user.id,
                      'createdAt': Timestamp.fromDate(DateTime.now()),
                      'type': 'image',
                      'uri': imageUrl,
                      'name': nonNullableResult.name ?? 'Image',
                      'size': file.lengthSync(),
                      'status': 'sent',
                    });
                    _updateChatMetadata('📷 Image');
                  } catch (e, stack) {
                    print('Image upload error: $e');
                    print(stack);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Image upload failed: $e'), backgroundColor: Colors.red),
                    );
                  }
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.videocam, color: Color(0xFF6C5CE7)),
              title: const Text('Video'),
              onTap: () async {
                Navigator.pop(context);
                final result = await _imagePicker.pickVideo(source: ImageSource.gallery);
                if (result != null) {
                  final user = FirebaseAuth.instance.currentUser;
                  if (user == null) return;

                  final nonNullableResult = result;

                  try {
                    String videoUrl;
                    int size;
                    if (kIsWeb) {
                      Uint8List bytes = await nonNullableResult.readAsBytes();
                      size = bytes.length;
                      final response = await cloudinary.uploadFile(
                        CloudinaryFile.fromBytesData(
                          bytes,
                          resourceType: CloudinaryResourceType.Video,
                          folder: 'chat_videos',
                          identifier: nonNullableResult.name,
                        ),
                      );
                      videoUrl = response.secureUrl;
                    } else {
                      final file = File(nonNullableResult.path);
                      size = file.lengthSync();
                      final response = await cloudinary.uploadFile(
                        CloudinaryFile.fromFile(
                          file.path,
                          resourceType: CloudinaryResourceType.Video,
                          folder: 'chat_videos',
                          identifier: nonNullableResult.name,
                        ),
                      );
                      videoUrl = response.secureUrl;
                    }
                    if (videoUrl == null || videoUrl.isEmpty) {
                      throw Exception('Video upload failed: No URL returned');
                    }
                    print('Video uploaded successfully. URL: $videoUrl');
                    await FirebaseFirestore.instance
                        .collection('chats')
                        .doc(widget.chatId)
                        .collection('messages')
                        .add({
                      'authorId': _user.id,
                      'createdAt': Timestamp.fromDate(DateTime.now()),
                      'type': 'custom',
                      'metadata': {
                        'messageType': 'video',
                        'uri': videoUrl,
                        'name': nonNullableResult.name,
                        'size': size,
                      },
                      'status': 'sent',
                    });
                    _updateChatMetadata('🎥 Video');
                  } catch (e, stack) {
                    print('Video upload error: $e');
                    print(stack);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Video upload failed: $e'), backgroundColor: Colors.red),
                    );
                  }
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.audiotrack, color: Color(0xFF6C5CE7)),
              title: const Text('Audio'),
              onTap: () {
                Navigator.pop(context);
                _handleVoiceRecording();
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showTextMessageDialog() {
    final textController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Send Text Message'),
        content: TextField(
          controller: textController,
          decoration: const InputDecoration(hintText: 'Type your message...'),
          autofocus: true,
          maxLines: null,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              final text = textController.text.trim();
              if (text.isNotEmpty) {
                _handleSendPressed(types.PartialText(text: text));
                Navigator.pop(context);
              }
            },
            child: const Text('Send'),
          ),
        ],
      ),
    );
  }

  void _listenForNewIncomingCalls() {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;

    _incomingCallSub = FirebaseFirestore.instance
        .collection('calls')
        .where('receiverId', isEqualTo: currentUser.uid)
        .where('status', isEqualTo: 'ringing')
        .snapshots()
        .listen((snapshot) {
      if (snapshot.docs.isNotEmpty) {
        // Found an incoming call
        final callDoc = snapshot.docs.first; // Assuming only one incoming call at a time
        final callData = callDoc.data();
        final callerName = callData['callerName'] as String? ?? 'Unknown Caller';
        final callerAvatar = callData['avatar'] as String? ?? '';
        final channelName = callData['channel'] as String?;
        final callType = callData['type'] as String?;

        if (channelName != null && callType != null) {
           // Stop any existing ringtone (though none should be playing here)
           _ringtonePlayer.stop();

           _showIncomingCallDialog(
             callDoc.id,
             callerName,
             callerAvatar,
             channelName,
             callType == 'video',
           );
        }
      }
    });
  }

  void _showIncomingCallDialog(
    String callDocId,
    String callerName,
    String callerAvatar,
    String channelName,
    bool isVideo,
  ) {
    showDialog(
      context: context,
      barrierDismissible: false, // Prevent dismissing by tapping outside
      builder: (context) => AlertDialog(
        title: const Text('Incoming Call'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircleAvatar(
              radius: 40,
              backgroundImage: callerAvatar.isNotEmpty ? NetworkImage(callerAvatar) : null,
              child: callerAvatar.isEmpty ? Icon(Icons.person, size: 40, color: Colors.grey) : null,
            ),
            const SizedBox(height: 16),
            Text(
              '${isVideo ? 'Video' : 'Voice'} call from $callerName',
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => _declineIncomingCall(callDocId),
            child: const Text('Decline', style: TextStyle(color: Colors.red)),
          ),
          ElevatedButton(
            onPressed: () => _acceptIncomingCall(callDocId, channelName, isVideo),
            child: const Text('Accept'),
          ),
        ],
      ),
    );
  }

  Future<void> _acceptIncomingCall(String callDocId, String channelName, bool isVideo) async {
    try {
      // Update call status to accepted
      await FirebaseFirestore.instance
          .collection('calls')
          .doc(callDocId)
          .update({'status': 'accepted'});

      // Dismiss the dialog
      if (mounted) Navigator.of(context).pop();

      // Navigate to the call screen
      if (mounted) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => CallScreen(
              channelName: channelName,
              isVideo: isVideo,
              contactName: '', // Caller name will be shown on call screen
              contactAvatar: '', // Caller avatar will be shown on call screen
              callDocId: callDocId, // Pass call document ID
              // We don't have contactId easily here, CallScreen can fetch if needed
            ),
          ),
        );
      }

    } catch (e) {
      print('Error accepting call: $e');
      // Optionally show an error message and dismiss dialog
       if (mounted) Navigator.of(context).pop();
    }
  }

   Future<void> _declineIncomingCall(String callDocId) async {
    try {
      // Update call status to declined or ended
      await FirebaseFirestore.instance
          .collection('calls')
          .doc(callDocId)
          .update({'status': 'declined'}); // Or 'ended' depending on desired flow

      // Dismiss the dialog
      if (mounted) Navigator.of(context).pop();

    } catch (e) {
      print('Error declining call: $e');
      // Optionally show an error message and dismiss dialog
       if (mounted) Navigator.of(context).pop();
    }
  }

  Future<void> _startCall({required bool isVideo}) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    print('Attempting to start call with ${widget.contactId}, isVideo: $isVideo');

    // Fetch contact's full name and avatar
    final contactDoc = await FirebaseFirestore.instance.collection('users').doc(widget.contactId).get();
    final contactData = contactDoc.data();
    final contactFirstName = contactData?['firstName'] ?? '';
    final contactLastName = contactData?['lastName'] ?? '';
    final contactAvatar = contactData?['avatar'] ?? '';
    final contactDisplayName = [contactFirstName, contactLastName].where((s) => s.isNotEmpty).join(' ').trim();
    final contactFallbackName = contactData?['name'] ?? '';
    final nameToShow = contactDisplayName.isNotEmpty
        ? contactDisplayName
        : (contactFallbackName.isNotEmpty ? contactFallbackName : (contactData?['email'] ?? ''));

    try {
      // Create call document
      final callDoc = await FirebaseFirestore.instance.collection('calls').add({
        'callerId': user.uid,
        'receiverId': widget.contactId,
        'callerName': user.displayName,
        'receiverName': nameToShow,
        'avatar': contactAvatar,
        'type': isVideo ? 'video' : 'audio',
        'status': 'ringing',
        'timestamp': DateTime.now(),
      });

      print('Call document created with ID: ${callDoc.id}');

      // Add a small delay to allow Firestore to process the write
      await Future.delayed(const Duration(milliseconds: 500));

      // Navigate to CallScreen immediately for the caller.
      if (!mounted) return;
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => CallScreen(
            isVideo: isVideo,
            channelName: tempChannelName, // Use temporary channel name for testing
            token: tempAgoraToken, // Use temporary token for testing
            contactName: nameToShow,
            contactAvatar: contactAvatar,
            callDocId: callDoc.id, // Pass the call document ID
          ),
        ),
      );

      // Note: The CallScreen will need to listen to the callDocId stream
      // to handle call state changes (ringing, accepted, declined, ended)
      // and manage the ringtone playback accordingly.
      // The ringtone logic from here is removed as CallScreen should handle it.
    } catch (e) {
      print('Error starting call or creating document: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to start call: ${e.toString()}')),
      );
    }
  }

  void _showEditContactDialog() {
    final firstNameController = TextEditingController();
    final lastNameController = TextEditingController();
    final emailController = TextEditingController();
    final phoneController = TextEditingController();

    // Pre-fill the controllers with existing data
    FirebaseFirestore.instance
        .collection('users')
        .doc(widget.contactId)
        .get()
        .then((doc) {
      if (doc.exists) {
        final data = doc.data() as Map<String, dynamic>;
        firstNameController.text = data['firstName'] ?? '';
        lastNameController.text = data['lastName'] ?? '';
        emailController.text = data['email'] ?? '';
        phoneController.text = data['phone'] ?? '';
      }
    });

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Contact'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: firstNameController,
                decoration: const InputDecoration(
                  labelText: 'First Name',
                  prefixIcon: Icon(Icons.person),
                ),
                textCapitalization: TextCapitalization.words,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: lastNameController,
                decoration: const InputDecoration(
                  labelText: 'Last Name',
                  prefixIcon: Icon(Icons.person_outline),
                ),
                textCapitalization: TextCapitalization.words,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: emailController,
                decoration: const InputDecoration(
                  labelText: 'Email',
                  prefixIcon: Icon(Icons.email),
                ),
                keyboardType: TextInputType.emailAddress,
                enabled: false, // Email cannot be changed
              ),
              const SizedBox(height: 12),
              TextField(
                controller: phoneController,
                decoration: const InputDecoration(
                  labelText: 'Phone Number',
                  prefixIcon: Icon(Icons.phone),
                ),
                keyboardType: TextInputType.phone,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final firstName = firstNameController.text.trim();
              final lastName = lastNameController.text.trim();
              final phone = phoneController.text.trim();

              if (firstName.isEmpty || lastName.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('First and last name are required')),
                );
                return;
              }

              try {
                print('Attempting to update contact.');
                // Update the contact's user profile
                await FirebaseFirestore.instance
                    .collection('users')
                    .doc(widget.contactId)
                    .update({
                  'firstName': firstName,
                  'lastName': lastName,
                  'phone': phone,
                });

                print('Contact user profile updated.');

                // Update the contact in the current user's contacts
                final currentUser = FirebaseAuth.instance.currentUser;
                if (currentUser != null) {
                   print('Current user logged in, attempting to update contact in user\'s collection.');
                  await FirebaseFirestore.instance
                      .collection('users')
                      .doc(currentUser.uid)
                      .collection('contacts')
                      .doc(widget.contactId)
                      .update({
                    'firstName': firstName,
                    'lastName': lastName,
                    'phone': phone,
                  });
                  print('Contact in user\'s collection updated.');
                }

                // After successful update, update the chat document in the current user's chats collection
                print('Attempting to update chat metadata.');
                final contactDoc = await FirebaseFirestore.instance.collection('users').doc(widget.contactId).get();
                final contactData = contactDoc.data();
                final contactFirstName = contactData?['firstName'] ?? '';
                final contactLastName = contactData?['lastName'] ?? '';
                final contactAvatar = contactData?['avatar'] ?? '';
                final contactDisplayName = [contactFirstName, contactLastName].where((s) => s.isNotEmpty).join(' ').trim();
                final contactFallbackName = contactData?['name'] ?? '';
                final nameToShow = contactDisplayName.isNotEmpty
                    ? contactDisplayName
                    : (contactFallbackName.isNotEmpty ? contactFallbackName : (contactData?['email'] ?? ''));

                await FirebaseFirestore.instance
                    .collection('users')
                    .doc(currentUser?.uid)
                    .collection('chats')
                    .doc(widget.chatId)
                    .set({
                  'contactName': nameToShow,
                  'firstName': contactFirstName,
                  'lastName': contactLastName,
                  'contactAvatar': contactAvatar,
                }, SetOptions(merge: true));
                print('Chat metadata updated.');

                if (mounted) {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Contact updated successfully')),
                  );
                  print('Success snackbar shown.');
                }
              } catch (e) {
                print('Error caught during contact update: $e');
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Failed to update contact')),
                  );
                  print('Failure snackbar shown.');
                }
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _handleMessageLongPress(BuildContext context, types.Message message) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.reply, color: Color(0xFF6C5CE7)),
              title: const Text('Reply'),
              onTap: () {
                Navigator.pop(context);
                print('Reply to message: ${message.id}');
              },
            ),
            ListTile(
              leading: const Icon(Icons.forward, color: Color(0xFF6C5CE7)),
              title: const Text('Forward'),
              onTap: () {
                Navigator.pop(context);
                print('Forward message: ${message.id}');
              },
            ),
            if (message.author.id == _user.id)
              ListTile(
                leading: const Icon(Icons.delete, color: Colors.redAccent),
                title: const Text('Delete'),
                onTap: () async {
                  Navigator.pop(context);
                  try {
                    await FirebaseFirestore.instance
                        .collection('chats')
                        .doc(widget.chatId)
                        .collection('messages')
                        .doc(message.id)
                        .delete();
                     print('Message deleted: ${message.id}');
                  } catch (e) {
                    print('Error deleting message: $e');
                  }
                },
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _setupFcm() async {
    // Request notification permissions
    NotificationSettings settings = await FirebaseMessaging.instance.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );

    print('User granted permission: ${settings.authorizationStatus}');

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      // Get the FCM token
      String? fcmToken = await FirebaseMessaging.instance.getToken();
      print('FCM Token: $fcmToken');

      // Save the token to Firestore
      if (fcmToken != null) {
        _saveFcmToken(fcmToken);
      }

      // Listen for token changes (optional but recommended)
      FirebaseMessaging.instance.onTokenRefresh.listen((newToken) {
        print('FCM Token refreshed: $newToken');
        _saveFcmToken(newToken);
      });
    }

    // Handle messages when the app is in the foreground
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      print('Got a message whilst in the foreground!');
      print('Message data: ${message.data}');

      // Process the incoming call notification here and show the dialog
      final callData = message.data;
      final callDocId = callData['callDocId'] as String?;
      final callerName = callData['callerName'] as String?;
      final callerAvatar = callData['callerAvatar'] as String?;
      final channelName = callData['channelName'] as String?;
      final callType = callData['callType'] as String?;

      if (callDocId != null && callerName != null && callerAvatar != null && channelName != null && callType != null) {
         // Show the incoming call dialog
         _showIncomingCallDialog(
           callDocId,
           callerName,
           callerAvatar,
           channelName,
           callType == 'video',
         );
      }
    });

    // Handle messages when the app is in the background or terminated
    // You need a separate top-level function for background messages (outside any class)
    // and potentially handle terminated state in your main.dart
  }

  Future<void> _saveFcmToken(String token) async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;

    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser.uid)
          .set({'fcmToken': token}, SetOptions(merge: true));
      print('FCM token saved for user ${currentUser.uid}');
    } catch (e) {
      print('Error saving FCM token: $e');
    }
  }

  Future<void> _initAgora() async {
    // Request permissions
    // ... existing code ...
  }
}