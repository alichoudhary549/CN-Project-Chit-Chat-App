import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class GroupMediaScreen extends StatefulWidget {
  final String groupId;
  const GroupMediaScreen({Key? key, required this.groupId}) : super(key: key);

  @override
  State<GroupMediaScreen> createState() => _GroupMediaScreenState();
}

class _GroupMediaScreenState extends State<GroupMediaScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Media, Links, and Docs', style: TextStyle(fontFamily: 'Poppins')),
        backgroundColor: Colors.white,
        elevation: 1,
        iconTheme: const IconThemeData(color: Colors.black),
        bottom: TabBar(
          controller: _tabController,
          labelColor: const Color(0xFF6C5CE7),
          unselectedLabelColor: Colors.grey,
          indicatorColor: const Color(0xFF6C5CE7),
          tabs: const [
            Tab(text: 'Media'),
            Tab(text: 'Files'),
            Tab(text: 'Links'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildMediaTab(),
          _buildFilesTab(),
          _buildLinksTab(),
        ],
      ),
    );
  }

  Widget _buildMediaTab() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('groups')
          .doc(widget.groupId)
          .collection('messages')
          .where('type', whereIn: ['image', 'video'])
          .orderBy('createdAt', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const Center(child: Text('Error loading media'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final media = snapshot.data!.docs;
        if (media.isEmpty) {
          return const Center(child: Text('No media shared yet.'));
        }
        return GridView.builder(
          padding: const EdgeInsets.all(8),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 4,
            mainAxisSpacing: 4,
          ),
          itemCount: media.length,
          itemBuilder: (context, index) {
            final data = media[index].data() as Map<String, dynamic>;
            final isImage = data['type'] == 'image';
            return GestureDetector(
              onTap: () {
                // Preview image or video
                showDialog(
                  context: context,
                  builder: (context) => Dialog(
                    child: isImage
                        ? Image.network(data['uri'], fit: BoxFit.contain)
                        : AspectRatio(
                            aspectRatio: 16 / 9,
                            child: Center(child: Text('Video preview not implemented.')),
                          ),
                  ),
                );
              },
              child: isImage
                  ? Image.network(data['uri'], fit: BoxFit.cover)
                  : Container(
                      color: Colors.black12,
                      child: const Center(child: Icon(Icons.videocam, size: 32, color: Color(0xFF6C5CE7))),
                    ),
            );
          },
        );
      },
    );
  }

  Widget _buildFilesTab() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('groups')
          .doc(widget.groupId)
          .collection('messages')
          .where('type', isEqualTo: 'file')
          .orderBy('createdAt', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const Center(child: Text('Error loading files'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final files = snapshot.data!.docs;
        if (files.isEmpty) {
          return const Center(child: Text('No files shared yet.'));
        }
        return ListView.builder(
          itemCount: files.length,
          itemBuilder: (context, index) {
            final data = files[index].data() as Map<String, dynamic>;
            return ListTile(
              leading: const Icon(Icons.attach_file, color: Color(0xFF6C5CE7)),
              title: Text(data['name'] ?? 'File', style: const TextStyle(fontFamily: 'Poppins')),
              subtitle: Text('${(data['size'] ?? 0) ~/ 1024} KB'),
              trailing: IconButton(
                icon: const Icon(Icons.download, color: Color(0xFF6C5CE7)),
                onPressed: () {
                  // TODO: Implement file download
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Download not implemented.')));
                },
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildLinksTab() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('groups')
          .doc(widget.groupId)
          .collection('messages')
          .where('type', isEqualTo: 'text')
          .orderBy('createdAt', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const Center(child: Text('Error loading links'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final messages = snapshot.data!.docs;
        final links = messages.where((doc) {
          final data = doc.data() as Map<String, dynamic>;
          final text = data['text'] ?? '';
          final urlPattern = RegExp(r"https?://[\w\-._~:/?#\[\]@!$&'()*+,;=.]+", caseSensitive: false);
          return urlPattern.hasMatch(text);
        }).toList();
        if (links.isEmpty) {
          return const Center(child: Text('No links shared yet.'));
        }
        return ListView.builder(
          itemCount: links.length,
          itemBuilder: (context, index) {
            final data = links[index].data() as Map<String, dynamic>;
            final text = data['text'] ?? '';
            final urlPattern = RegExp(r"https?://[\w\-._~:/?#\[\]@!$&'()*+,;=.]+", caseSensitive: false);
            final match = urlPattern.firstMatch(text);
            final url = match?.group(0) ?? '';
            return ListTile(
              leading: const Icon(Icons.link, color: Color(0xFF6C5CE7)),
              title: Text(url, style: const TextStyle(fontFamily: 'Poppins', color: Color(0xFF6C5CE7))),
              subtitle: Text(text, style: const TextStyle(fontFamily: 'Poppins')),
              onTap: () {
                // TODO: Open link in browser
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Open link not implemented.')));
              },
            );
          },
        );
      },
    );
  }
} 