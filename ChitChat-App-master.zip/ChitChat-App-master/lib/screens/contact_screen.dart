import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'chat_room_screen.dart';
import 'package:cloudinary_public/cloudinary_public.dart';

class ContactScreen extends StatefulWidget {
  final String? contactId;
  final String? chatId;
  final String? mode;

  const ContactScreen({super.key, this.contactId, this.chatId, this.mode});

  @override
  State<ContactScreen> createState() => _ContactScreenState();
}

class _ContactScreenState extends State<ContactScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _searchController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  List<Map<String, dynamic>> _filteredContacts = [];
  List<Map<String, dynamic>> _allContacts = [];
  bool _isAddingByPhone = true;
  bool _isSearching = false;
  String _searchQuery = '';
  final cloudinary = CloudinaryPublic('dkuyjynpe', 'statuses', cache: false);

  get publish => null;

  @override
  void initState() {
    super.initState();
    _fetchContacts();
    _searchController.addListener(_filterContacts);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _fetchContacts() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final snapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .collection('contacts')
        .orderBy('name')
        .get();

    if (mounted) {
      setState(() {
        _allContacts = snapshot.docs.map((doc) => {
          'id': doc.id,
          ...doc.data(),
        }).toList();
        _filteredContacts = List.from(_allContacts);
      });
    }
  }

  void _filterContacts() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _isSearching = query.isNotEmpty;
      _filteredContacts = _allContacts.where((contact) {
        final name = contact['name'].toLowerCase();
        final phone = contact['phone']?.toLowerCase() ?? '';
        final email = contact['email']?.toLowerCase() ?? '';
        return name.contains(query) ||
            phone.contains(query) ||
            email.contains(query);
      }).toList();
    });
  }

  Future<void> _toggleFavorite(String contactId, bool isFavorite) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    await FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .collection('contacts')
        .doc(contactId)
        .update({'isFavorite': !isFavorite});

    _fetchContacts();
  }

  void _addContact() async {
    if (_formKey.currentState?.validate() ?? false) {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final contactData = {
        'name': _nameController.text,
        'createdAt': Timestamp.now(),
        'isFavorite': false,
        if (_phoneController.text.isNotEmpty) 'phone': _phoneController.text,
        if (_emailController.text.isNotEmpty) 'email': _emailController.text,
      };

      await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .collection('contacts')
          .add(contactData);

      _nameController.clear();
      _phoneController.clear();
      _emailController.clear();
      if (mounted) Navigator.pop(context);
      _fetchContacts();
    }
  }

  void _showAddContactDialog() {
    final firstNameController = TextEditingController();
    final lastNameController = TextEditingController();
    final emailController = TextEditingController();
    final phoneController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Contact'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: firstNameController,
                decoration: const InputDecoration(
                  labelText: 'First Name',
                  prefixIcon: Icon(Icons.person),
                ),
                textCapitalization: TextCapitalization.words,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: lastNameController,
                decoration: const InputDecoration(
                  labelText: 'Last Name',
                  prefixIcon: Icon(Icons.person_outline),
                ),
                textCapitalization: TextCapitalization.words,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: emailController,
                decoration: const InputDecoration(
                  labelText: 'Email (required)',
                  prefixIcon: Icon(Icons.email),
                ),
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: phoneController,
                decoration: const InputDecoration(
                  labelText: 'Phone Number (optional)',
                  prefixIcon: Icon(Icons.phone),
                ),
                keyboardType: TextInputType.phone,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final firstName = firstNameController.text.trim();
              final lastName = lastNameController.text.trim();
              final email = emailController.text.trim();
              final phone = phoneController.text.trim();

              if (firstName.isEmpty || lastName.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('First and last name are required')),
                );
                return;
              }
              if (email.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Email is required')),
                );
                return;
              }

              final user = FirebaseAuth.instance.currentUser;
              if (user == null) return;

              // Check if the email is registered as a user
              final userSnap = await FirebaseFirestore.instance
                  .collection('users')
                  .where('email', isEqualTo: email)
                  .limit(1)
                  .get();

              final bool isRegistered = userSnap.docs.isNotEmpty;
              final String contactDocId;

              if (isRegistered) {
                contactDocId = userSnap.docs.first.id;
                // Check for duplicate registered user contact
                 final existingContactDoc = await FirebaseFirestore.instance
                    .collection('users')
                    .doc(user.uid)
                    .collection('contacts')
                    .doc(contactDocId)
                    .get();

                 if (existingContactDoc.exists) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('This user is already in your contacts.')),
                    );
                    return;
                 }

              } else {
                 // For unregistered users, generate a unique ID for the contact document
                 // and check for duplicate unregistered user contact by email
                 final existingUnregisteredContact = await FirebaseFirestore.instance
                    .collection('users')
                    .doc(user.uid)
                    .collection('contacts')
                    .where('email', isEqualTo: email)
                    .limit(1)
                    .get();

                 if (existingUnregisteredContact.docs.isNotEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('A contact with this email already exists.')),
                    );
                    return;
                 }

                 // Generate a new document ID for the unregistered contact
                 contactDocId = FirebaseFirestore.instance.collection('users').doc(user.uid).collection('contacts').doc().id;
              }

              try {
                // Add contact document to the current user's contacts subcollection
                await FirebaseFirestore.instance
                    .collection('users')
                    .doc(user.uid)
                    .collection('contacts')
                    .doc(contactDocId)
                    .set({
                  'firstName': firstName,
                  'lastName': lastName,
                  'email': email,
                  'phone': phone,
                  'addedAt': FieldValue.serverTimestamp(),
                  'isRegistered': isRegistered, // Add isRegistered field
                });

                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Contact added!' + (isRegistered ? '' : ' (Unregistered User)'))), // Indicate if unregistered
                  );
                  Navigator.pop(context);
                }
              } catch (e) {
                 print('Error adding contact: $e');
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Failed to add contact.')),
                  );
                }
              }
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: _isSearching
            ? TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  hintText: 'Search contacts...',
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(24),
                    borderSide: BorderSide.none,
                  ),
                  filled: true,
                  fillColor: Colors.grey[200],
                  contentPadding: const EdgeInsets.symmetric(vertical: 0),
                ),
                onChanged: (value) {
                  setState(() {
                    _searchQuery = value.trim().toLowerCase();
                  });
                },
              )
            : const Text('Contacts'),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_add),
            onPressed: _showAddContactDialog,
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(56),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search contacts...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.grey[200],
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value.trim().toLowerCase();
                });
              },
            ),
          ),
        ),
      ),
      body: Builder(
        builder: (context) {
          final user = FirebaseAuth.instance.currentUser;
          if (user == null) {
            return const Center(child: Text('Not logged in'));
          }
          return StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('users')
                .doc(user.uid)
                .collection('contacts')
                .orderBy('addedAt', descending: true)
                .snapshots(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.contacts, size: 80, color: Colors.grey[400]),
                      const SizedBox(height: 16),
                      Text(
                        'No contacts yet',
                        style: TextStyle(
                          fontSize: 20,
                          color: Colors.grey[600],
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Add contacts to start chatting or calling.',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.grey[500],
                        ),
                      ),
                    ],
                  ),
                );
              }
              final contacts = snapshot.data!.docs.where((doc) {
                final data = doc.data() as Map<String, dynamic>;
                final firstName = (data['firstName'] ?? '').toLowerCase();
                final lastName = (data['lastName'] ?? '').toLowerCase();
                final email = (data['email'] ?? '').toLowerCase();
                final phone = (data['phone'] ?? '').toLowerCase();
                return _searchQuery.isEmpty ||
                    firstName.contains(_searchQuery) ||
                    lastName.contains(_searchQuery) ||
                    email.contains(_searchQuery) ||
                    phone.contains(_searchQuery);
              }).toList();

              return ListView.separated(
                itemCount: contacts.length,
                separatorBuilder: (_, __) => const Divider(height: 0),
                itemBuilder: (context, index) {
                  final data = contacts[index].data() as Map<String, dynamic>;
                  final contactId = data['id'];

                  return Dismissible(
                    key: Key(contactId ?? 'contact_${index}'),
                    direction: DismissDirection.endToStart,
                    background: Container(
                      color: Colors.red,
                      alignment: Alignment.centerRight,
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: const Icon(Icons.delete, color: Colors.white),
                    ),
                    confirmDismiss: (direction) async {
                      if (direction == DismissDirection.endToStart) {
                        return await showDialog<bool>(
                          context: context,
                          builder: (context) => AlertDialog(
                            title: const Text('Delete Contact'),
                            content: const Text('Are you sure you want to delete this contact?'),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(context, false),
                                child: const Text('Cancel'),
                              ),
                              TextButton(
                                onPressed: () => Navigator.pop(context, true),
                                child: const Text('Delete', style: TextStyle(color: Colors.red)),
                              ),
                            ],
                          ),
                        );
                      }
                      return true;
                    },
                    onDismissed: (direction) async {
                      if (direction == DismissDirection.endToStart) {
                        final user = FirebaseAuth.instance.currentUser;
                        if (user == null) return;
                        if (contactId != null) {
                          await FirebaseFirestore.instance
                              .collection('users')
                              .doc(user.uid)
                              .collection('contacts')
                              .doc(contactId)
                              .delete();
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Contact deleted')),
                          );
                        }
                      } else if (direction == DismissDirection.startToEnd) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Edit swipe not fully implemented yet.')),
                        );
                      }
                    },
                    child: ListTile(
                      leading: CircleAvatar(
                        radius: 25,
                        backgroundColor: Colors.grey[300],
                        child: Text(
                          (data['firstName'] ?? 'U')[0].toUpperCase(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                          ),
                        ),
                      ),
                      title: Text(
                        ((data['firstName'] != null && data['firstName'].toString().trim().isNotEmpty) ||
                         (data['lastName'] != null && data['lastName'].toString().trim().isNotEmpty))
                          ? '${data['firstName'] ?? ''} ${data['lastName'] ?? ''}'.trim()
                          : (data['email'] ?? ''),
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: (data['email'] != null && data['email'] != '')
                          ? Text('Email: ${data['email']}')
                          : (data['phone'] != null && data['phone'] != '')
                              ? Text('Phone: ${data['phone']}')
                              : null,
                      onTap: () async {
                        final currentUser = FirebaseAuth.instance.currentUser;
                        if (currentUser == null) return;

                        final contactData = data;
                        print('Tapped contact data: $contactData');
                        final bool isRegistered = contactData['isRegistered'] ?? false;
                        final String? storedContactId = contactData['id']; // This is the document ID in the contacts subcollection
                        final String? contactEmail = contactData['email'];
                        final String? contactFirstName = contactData['firstName'];
                        final String? contactLastName = contactData['lastName'];

                        String? targetUserId;
                        String nameToShow;
                        String avatarUrl = '';

                        if (isRegistered && storedContactId != null) {
                          // If marked as registered, use the stored contactId (which should be the UID)
                          targetUserId = storedContactId;
                          // Fetch the user's actual data from the main users collection for the chat header
                          try {
                            final userDoc = await FirebaseFirestore.instance.collection('users').doc(targetUserId).get();
                            if (userDoc.exists) {
                                final userData = userDoc.data();
                                final userFirstName = userData?['firstName'] ?? '';
                                final userLastName = userData?['lastName'] ?? '';
                                final userDisplayName = [userFirstName, userLastName].where((s) => s.isNotEmpty).join(' ').trim();
                                nameToShow = userDisplayName.isNotEmpty ? userDisplayName : (userData?['name'] ?? userData?['email'] ?? 'Unknown');
                                avatarUrl = userData?['avatar'] ?? '';
                            } else {
                                // Fallback to stored contact name if user doc not found (shouldn't happen for registered)
                                nameToShow = '${contactFirstName ?? ''} ${contactLastName ?? ''}'.trim();
                                if (nameToShow.isEmpty) nameToShow = contactEmail ?? 'Unknown';
                            }
                          } catch (e) {
                             print('Error fetching registered user data: $e');
                              // Fallback to stored contact name on error
                             nameToShow = '${contactFirstName ?? ''} ${contactLastName ?? ''}'.trim();
                             if (nameToShow.isEmpty) nameToShow = contactEmail ?? 'Unknown';
                          }

                        } else if (contactEmail != null && contactEmail.isNotEmpty) {
                          // If not marked as registered, or no stored ID, try finding by email
                          final userSnap = await FirebaseFirestore.instance
                              .collection('users')
                              .where('email', isEqualTo: contactEmail)
                              .limit(1)
                              .get();

                          if (userSnap.docs.isNotEmpty) {
                            targetUserId = userSnap.docs.first.id;
                             // User is now registered, potentially update the contact document
                             // to mark as registered and maybe change doc ID to targetUserId
                             // This is a more complex step and can be implemented later.

                             final userData = userSnap.docs.first.data() as Map<String, dynamic>;
                             final userFirstName = userData['firstName'] ?? '';
                             final userLastName = userData['lastName'] ?? '';
                             final userDisplayName = [userFirstName, userLastName].where((s) => s.isNotEmpty).join(' ').trim();
                             nameToShow = userDisplayName.isNotEmpty ? userDisplayName : (userData['name'] ?? userData['email'] ?? 'Unknown');
                             avatarUrl = userData['avatar'] ?? '';

                          } else {
                             // User still not found in main users collection
                             targetUserId = null;
                             nameToShow = '${contactFirstName ?? ''} ${contactLastName ?? ''}'.trim();
                             if (nameToShow.isEmpty) nameToShow = contactEmail ?? 'Unknown';
                          }
                        } else {
                           // No email or stored ID available
                           targetUserId = null;
                           nameToShow = '${contactFirstName ?? ''} ${contactLastName ?? ''}'.trim();
                           if (nameToShow.isEmpty) nameToShow = 'Unknown';
                        }

                        if (targetUserId != null) {
                           final chatId = ChatRoomScreen.getChatId(currentUser.uid, targetUserId);
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ChatRoomScreen(
                                chatId: chatId,
                                contactName: nameToShow, // Use the determined name
                                contactId: targetUserId!, // Pass the determined user ID
                                contactAvatar: avatarUrl, // Pass the determined avatar
                              ),
                            ),
                          );
                        } else {
                           ScaffoldMessenger.of(context).showSnackBar(
                             const SnackBar(content: Text('User not found for this contact.')),
                           );
                        }
                      },
                    ),
                  );
                },
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddContactDialog,
        backgroundColor: Theme.of(context).primaryColor,
        child: const Icon(Icons.person_add, color: Colors.white),
      ),
    );
  }

  Widget _buildQuickAction({required IconData icon, required String label, required int count}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        decoration: BoxDecoration(
          color: Colors.grey.shade50,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Icon(icon, color: const Color(0xFF6C5CE7)),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey.shade700,
                  ),
                ),
                Text(
                  "$count",
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Colors.black,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactItem(Map<String, dynamic> contact) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: _getAvatarColor(contact['name']),
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Text(
              contact['name'][0].toUpperCase(),
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
          ),
        ),
        title: Text(
          contact['name'],
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        subtitle: Text(
          contact['phone'] ?? contact['email'] ?? '',
          style: TextStyle(
            color: Colors.grey.shade600,
          ),
        ),
        trailing: IconButton(
          icon: Icon(
            contact['isFavorite'] == true ? Icons.star : Icons.star_border,
            color: contact['isFavorite'] == true ? Colors.amber : Colors.grey.shade400,
          ),
          onPressed: () => _toggleFavorite(contact['id'], contact['isFavorite'] ?? false),
        ),
        onTap: () {
          final currentUserId = FirebaseAuth.instance.currentUser!.uid;
          final contactId = contact['id'];
          final chatId = ChatRoomScreen.getChatId(currentUserId, contactId);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ChatRoomScreen(
                chatId: chatId,
                contactName: contact['name'],
                contactId: contactId,
              ),
            ),
          );
        },
      ),
    );
  }

  Color _getAvatarColor(String name) {
    final colors = [
      const Color(0xFF6C5CE7),
      const Color(0xFF00B894),
      const Color(0xFFFD79A8),
      const Color(0xFFE17055),
      const Color(0xFF0984E3),
    ];
    return colors[name.hashCode % colors.length];
  }
}