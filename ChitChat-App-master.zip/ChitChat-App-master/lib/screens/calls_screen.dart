import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:async';
import 'contact_screen.dart'; // Assuming ContactScreen is in the same directory
import 'call_screen.dart';

class CallsScreen extends StatefulWidget {
  const CallsScreen({super.key});

  @override
  State<CallsScreen> createState() => _CallsScreenState();
}

class _CallsScreenState extends State<CallsScreen> {
  List<DocumentSnapshot> _calls = [];
  bool _isLoading = true;
  String? _errorMessage;
  StreamSubscription<QuerySnapshot>? _callerCallsSubscription;
  StreamSubscription<QuerySnapshot>? _calleeCallsSubscription;

  // Add separate lists for caller and callee calls
  List<DocumentSnapshot> _callerCalls = [];
  List<DocumentSnapshot> _calleeCalls = [];

  @override
  void initState() {
    super.initState();
    _fetchCalls();
  }

  @override
  void dispose() {
    _callerCallsSubscription?.cancel();
    _calleeCallsSubscription?.cancel();
    super.dispose();
  }

  Future<void> _fetchCalls() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'User not logged in';
      });
      return;
    }

    try {
      // Listen to calls where the current user is the caller
      _callerCallsSubscription = FirebaseFirestore.instance
          .collection('calls')
          .where('callerId', isEqualTo: user.uid)
          .orderBy('timestamp', descending: true)
          .snapshots()
          .listen((snapshot) {
            // Log number of caller calls received
            print('DEBUG: Received ${snapshot.docs.length} caller calls');
            _callerCalls = snapshot.docs;
            _combineAndSortCalls(); // Combine and sort after receiving caller calls
          });

      // Listen to calls where the current user is the callee
      _calleeCallsSubscription = FirebaseFirestore.instance
          .collection('calls')
          .where('receiverId', isEqualTo: user.uid)
          .orderBy('timestamp', descending: true)
          .snapshots()
          .listen((snapshot) {
            // Log number of callee calls received
            print('DEBUG: Received ${snapshot.docs.length} callee calls');
            _calleeCalls = snapshot.docs;
            _combineAndSortCalls(); // Combine and sort after receiving callee calls
          });

      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    } catch (e) {
       if (mounted) {
        setState(() {
          _isLoading = false;
          _errorMessage = 'Failed to set up call streams: ${e.toString()}';
        });
       }
    }
  }

  // Method to combine and sort calls from both streams
  void _combineAndSortCalls() {
    // Combine the two lists
    final combinedCalls = [..._callerCalls, ..._calleeCalls];

    // Use a map to filter out duplicates based on document ID
    final Map<String, DocumentSnapshot> uniqueCallsMap = {};
    for (var doc in combinedCalls) {
      uniqueCallsMap[doc.id] = doc; // Add or update by ID
    }

    final allCalls = uniqueCallsMap.values.toList();

    // Log the number of unique calls and the data of each call
    print('DEBUG: Combined and sorted ${allCalls.length} unique calls:');
    for (var callDoc in allCalls) {
      print('DEBUG: Call data: ${callDoc.data()}');
    }

    // Sort the combined and unique list by timestamp
    allCalls.sort((a, b) => (b['timestamp'] as Timestamp).compareTo(a['timestamp'] as Timestamp));

    if (mounted) {
      setState(() {
        _calls = allCalls;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) {
       return const Center(child: Text('Not logged in'));
    }

    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_errorMessage != null) {
      return Center(child: Text('Error: $_errorMessage'));
    }

    if (_calls.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.call, size: 80, color: Colors.grey[400]),
            const SizedBox(height: 16),
            Text(
              'No recent calls',
              style: TextStyle(
                fontSize: 20,
                color: Colors.grey[600],
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Your recent calls will appear here.',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[500],
              ),
            ),
          ],
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Calls'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_call),
            onPressed: () {
              // TODO: Navigate to contacts to start a new call
               Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ContactScreen(mode: 'call'),
                ),
              );
            },
          ),
        ],
      ),
      body: ListView.separated(
        itemCount: _calls.length,
        separatorBuilder: (_, __) => const Divider(height: 0),
        itemBuilder: (context, index) {
          final callDoc = _calls[index];
          final call = callDoc.data() as Map<String, dynamic>;
          final currentUserUid = FirebaseAuth.instance.currentUser!.uid; // Get current user's UID

          // Determine the name to display (the other user's name)
          final name = call['callerId'] == currentUserUid
              ? call['receiverName'] ?? 'Unknown'
              : call['callerName'] ?? 'Unknown';

          final callId = callDoc.id; // Get the document ID for Dismissible key
          final isVideoCall = call['type'] == 'video'; // Check 'type' field for video/audio
          final channelName = call['channel'];
          final contactAvatar = call['avatar'] as String? ?? ''; // Get avatar

          return Dismissible(
            key: Key(callId),
            direction: DismissDirection.endToStart,
            background: Container(
              color: Colors.red,
              alignment: Alignment.centerRight,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: const Icon(Icons.delete, color: Colors.white),
            ),
            onDismissed: (direction) async {
              await FirebaseFirestore.instance
                  .collection('calls')
                  .doc(callId)
                  .delete();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Call deleted')),
              );
            },
            child: ListTile(
              tileColor: Colors.blue.shade50, // Add a background color for debugging
              leading: CircleAvatar(
                radius: 25,
                backgroundColor: Colors.grey[300],
                backgroundImage: contactAvatar.isNotEmpty
                    ? NetworkImage(contactAvatar)
                    : null,
                child: contactAvatar.isEmpty
                    ? const Icon(Icons.person, color: Colors.white)
                    : null,
              ),
              title: Text(
                name,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Row(
                children: [
                  Icon(
                    call['callerId'] == user.uid
                        ? Icons.call_made // Outgoing
                        : Icons.call_received, // Incoming
                    size: 16,
                    color: call['status'] == 'missed' // Check for missed status
                        ? Colors.red
                        : Colors.green,
                  ),
                  const SizedBox(width: 4),
                  // Displaying timestamp instead of just time
                  Text(
                    call['timestamp'] != null
                        ? (call['timestamp'] as Timestamp).toDate().toString() // Format as needed
                        : '',
                    style: TextStyle(
                      color: call['status'] == 'missed'
                          ? Colors.red
                          : Colors.grey[600],
                    ),
                  ),
                ],
              ),
              trailing: Row(
                 mainAxisSize: MainAxisSize.min,
                 children: [
                   // Add warning icon for unregistered users
                   if (call.containsKey('isRegistered') && call['isRegistered'] == false)
                     Tooltip(
                       message: 'User not on ChitChat',
                       child: Icon(
                         Icons.warning_amber_outlined,
                         color: Colors.orangeAccent,
                         size: 20,
                       ),
                     ),
                   const SizedBox(width: 8), // Spacing between icon and call button
                   IconButton(
                     icon: Icon(
                       isVideoCall ? Icons.videocam : Icons.call,
                       color: Theme.of(context).primaryColor,
                     ),
                     onPressed: () {
                        // Attempt to initiate a call back
                        // Note: Full call initiation logic needs to be robust
                        // Pass necessary data to the CallScreen
                        if (channelName != null) {
                            // Determine the other user's ID for initiating the call back
                            final otherUserId = call['callerId'] == user.uid ? call['receiverId'] : call['callerId'];

                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => CallScreen(
                                        isVideo: isVideoCall,
                                        channelName: channelName as String,
                                        token: null, // Token handling needed
                                        contactName: name, // Pass the displayed name
                                        contactAvatar: contactAvatar, // Pass the avatar
                                        contactId: otherUserId, // Pass the other user's ID
                                    ),
                                ),
                            );
                        }
                     },
                   ),
                 ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class CallDetailScreen extends StatelessWidget {
  final Map<String, dynamic> call;
  const CallDetailScreen({required this.call, super.key});

  @override
  Widget build(BuildContext context) {
    final name = (call['firstName'] != null && call['lastName'] != null &&
                  (call['firstName'] as String).isNotEmpty)
        ? ((call['firstName'] as String) + ' ' + (call['lastName'] as String)).trim()
        : (call['name'] != null && (call['name'] as String).isNotEmpty)
            ? call['name']
            : (call['email'] != null && (call['email'] as String).isNotEmpty)
                ? call['email']
                : 'Unknown';
    return Scaffold(
      appBar: AppBar(
        title: Text(name),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            CircleAvatar(
              radius: 40,
              backgroundColor: Colors.grey[300],
              backgroundImage: call['avatar'] != null && call['avatar'] != ''
                  ? NetworkImage(call['avatar'])
                  : null,
              child: (call['avatar'] == null || call['avatar'] == '')
                  ? Icon(
                      call['isVideo'] == true ? Icons.videocam : Icons.person,
                      color: Colors.white,
                      size: 40,
                    )
                  : null,
            ),
            const SizedBox(height: 16),
            Text(
              name,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  call['isVideo'] == true ? Icons.videocam : Icons.call,
                  color: Theme.of(context).primaryColor,
                ),
                const SizedBox(width: 8),
                Text(
                  call['isVideo'] == true ? 'Video Call' : 'Voice Call',
                  style: TextStyle(
                    color: Theme.of(context).primaryColor,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ListTile(
              leading: Icon(
                call['incoming'] == true
                    ? Icons.call_received
                    : Icons.call_made,
                color: call['isMissed'] == true ? Colors.red : Colors.green,
              ),
              title: Text(
                call['isMissed'] == true
                    ? 'Missed Call'
                    : call['incoming'] == true
                        ? 'Incoming Call'
                        : 'Outgoing Call',
              ),
              subtitle: Text(call['time'] ?? ''),
            ),
            const Spacer(),
            ElevatedButton.icon(
              onPressed: () {
                // TODO: Implement redial or call-back
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Redialing...')),
                );
              },
              icon: Icon(
                call['isVideo'] == true ? Icons.videocam : Icons.call,
              ),
              label: Text(
                call['isVideo'] == true ? 'Video Call' : 'Voice Call',
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Theme.of(context).primaryColor,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                textStyle: const TextStyle(fontSize: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
