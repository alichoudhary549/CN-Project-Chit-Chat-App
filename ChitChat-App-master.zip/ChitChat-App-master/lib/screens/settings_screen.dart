import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notificationsEnabled = true;
  bool _isDarkTheme = false;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _fetchSettings();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<void> _fetchSettings() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    setState(() => _isLoading = true);
    try {
      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();
      if (doc.exists) {
        final data = doc.data()!;
        setState(() {
          _notificationsEnabled = data['notificationsEnabled'] ?? true;
          _isDarkTheme = data['isDarkTheme'] ?? false;
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error fetching settings: $e')),
      );
    }
  }

  Future<void> _updateSetting(String key, dynamic value) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .update({key: value});
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error updating setting: $e')),
      );
    }
  }

  Future<void> _logout() async {
    try {
      await FirebaseAuth.instance.signOut();
      if (mounted) {
        Navigator.pushReplacementNamed(context, '/login');
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error logging out: $e')),
      );
    }
  }

  Future<void> _deleteAccount() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    bool confirm = await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text(
          'Delete Account',
          style: TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.w700),
        ),
        content: const Text(
          'Are you sure you want to delete your account? This action cannot be undone.',
          style: TextStyle(fontFamily: 'Poppins'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text(
              'Cancel',
              style: TextStyle(fontFamily: 'Poppins', color: Color(0xFF6C5CE7)),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text(
              'Delete',
              style: TextStyle(fontFamily: 'Poppins', color: Colors.red),
            ),
          ),
        ],
      ),
    );

    if (confirm) {
      setState(() => _isLoading = true);
      try {
        // Delete user data from Firestore
        await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .delete();
        // Delete profile picture from Storage
        await FirebaseStorage.instance
            .ref()
            .child('profile_pictures')
            .child('${user.uid}.jpg')
            .delete()
            .catchError((e) => null); // Ignore if no profile picture
        // Delete user account
        await user.delete();
        if (mounted) {
          Navigator.pushReplacementNamed(context, '/login');
        }
      } catch (e) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error deleting account: $e')),
        );
      }
    }
  }

  Future<void> updateAllChatsWithRealNames() async {
    // Ensure Firebase is initialized if not already in your app's entry point
    // This might be redundant if your main.dart already initializes Firebase,
    // but adding it here makes the function runnable independently if needed.
    // try {
    //   Firebase.initializeApp();
    // } catch (e) {
    //   // Firebase might already be initialized
    //   print("Firebase already initialized or error initializing: $e");
    // }

    final usersRef = FirebaseFirestore.instance.collection('users');
    final users = await usersRef.get();

    for (final userDoc in users.docs) {
      final chatsRef = userDoc.reference.collection('chats');
      final chats = await chatsRef.get();
      for (final chatDoc in chats.docs) {
        final data = chatDoc.data();
        final contactId = data['contactId'];
        if (contactId == null) continue;

        // Fetch the contact's user profile
        final contactProfile = await usersRef.doc(contactId).get();
        final contactData = contactProfile.data();
        if (contactData == null) continue;

        final firstName = contactData['firstName'] ?? '';
        final lastName = contactData['lastName'] ?? '';

        // Only update if there's valid name data to add
        if (firstName.isNotEmpty || lastName.isNotEmpty) {
           await chatDoc.reference.set({
             'firstName': firstName,
             'lastName': lastName,
           }, SetOptions(merge: true));
           print('Updated chat ${chatDoc.id} for user ${userDoc.id} with name $firstName $lastName');
        } else {
           print('Skipping chat ${chatDoc.id} for user ${userDoc.id}: No name found in contact profile.');
        }
      }
    }
    print('All chats update process completed!');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Settings'),
        centerTitle: false,
      ),
      body: _isLoading
          ? const Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF6C5CE7)),
        ),
      )
          : ListView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        children: [
          // Notifications
          SwitchListTile(
            title: const Text(
              'Notifications',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                fontFamily: 'Poppins',
              ),
            ),
            subtitle: Text(
              'Receive notifications for new messages',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade600,
                fontFamily: 'Poppins',
              ),
            ),
            value: _notificationsEnabled,
            onChanged: (value) {
              setState(() => _notificationsEnabled = value);
              _updateSetting('notificationsEnabled', value);
            },
            activeColor: const Color(0xFF6C5CE7),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          const Divider(),
          // Theme
          ListTile(
            title: const Text(
              'Theme',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                fontFamily: 'Poppins',
              ),
            ),
            subtitle: Text(
              _isDarkTheme ? 'Dark' : 'Light',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade600,
                fontFamily: 'Poppins',
              ),
            ),
            trailing: Switch(
              value: _isDarkTheme,
              onChanged: (value) {
                setState(() => _isDarkTheme = value);
                _updateSetting('isDarkTheme', value);
                // Note: Actual theme switching requires app-level ThemeData update
              },
              activeColor: const Color(0xFF6C5CE7),
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          const Divider(),

           // Data Migration Button
          ElevatedButton(
            onPressed: () async {
              print('Starting chat data update...');
              await updateAllChatsWithRealNames();
              print('Chat data update finished.');
              // Optionally show a snackbar
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Chat data update attempt complete. Restart app.')),
              );
            },
            child: const Text('Run Data Migration (Debug)'),
          ),
          const Divider(),

          // Logout
          ListTile(
            title: const Text(
              'Logout',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                fontFamily: 'Poppins',
                color: Color(0xFF6C5CE7),
              ),
            ),
            leading: const Icon(
              Icons.logout,
              color: Color(0xFF6C5CE7),
            ),
            onTap: _logout,
          ),
          const Divider(),
          // Delete Account
          ListTile(
            title: const Text(
              'Delete Account',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                fontFamily: 'Poppins',
                color: Colors.redAccent,
              ),
            ),
            leading: const Icon(
              Icons.delete_forever,
              color: Colors.redAccent,
            ),
            onTap: _deleteAccount,
          ),
        ],
      ),
    );
  }
}