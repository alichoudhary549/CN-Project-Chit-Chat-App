import 'dart:io';
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:cloudinary_public/cloudinary_public.dart';
import 'status_full_screen_view.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'dart:typed_data';
import 'dart:io' if (dart.library.html) 'dart:html' as html;
import '../widgets/logo_widget.dart';
import '../widgets/video_player_widget.dart';

class StatusScreen extends StatefulWidget {
  final bool isFullScreen;
  final String? initialUserId;
  final int? initialIndex;
  
  const StatusScreen({
    super.key, 
    this.isFullScreen = false,
    this.initialUserId,
    this.initialIndex,
  });

  @override
  State<StatusScreen> createState() => _StatusScreenState();
}

class _StatusScreenState extends State<StatusScreen> {
  final List<Map<String, dynamic>> statuses = [];
  bool isLoading = true;
  Map<String, dynamic>? selectedStatus;
  bool isFullScreen = false;
  final String cloudName = 'dkuyjynpe';
  final String uploadPreset = 'ml_default';
  final cloudinary = CloudinaryPublic('dkuyjynpe', 'ml_default', cache: false);
  final _imagePicker = ImagePicker();
  Timer? _statusTimer;
  PageController? _pageController;

  @override
  void initState() {
    super.initState();
    isFullScreen = widget.isFullScreen;
    _fetchStatuses();
  }

  @override
  void dispose() {
    _statusTimer?.cancel();
    _pageController?.dispose();
    super.dispose();
  }

  Future<void> _fetchStatuses() async {
    try {
    final now = DateTime.now();
      final yesterday = now.subtract(const Duration(hours: 24));
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser == null) return;

      // Get current user's data
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser.uid)
          .get();

      final userName = userDoc.data()?['name'] ?? 'Unknown';
      final userAvatar = userDoc.data()?['avatar'] ?? '';

      final QuerySnapshot statusSnapshot = await FirebaseFirestore.instance
        .collection('statuses')
          .where('createdAt', isGreaterThan: yesterday)
          .orderBy('createdAt', descending: true)
        .get();

      final List<Map<String, dynamic>> fetchedStatuses = [];

      // Add current user's status first if exists
      final myStatusDocs = statusSnapshot.docs.where(
              (doc) => (doc.data() as Map<String, dynamic>)['userId'] == currentUser.uid
      );

      if (myStatusDocs.isNotEmpty) {
        for (var doc in myStatusDocs) {
          final status = doc.data() as Map<String, dynamic>;
          status['userName'] = userName;
          status['userAvatar'] = userAvatar;
          status['id'] = doc.id;
          status['isMyStatus'] = true;
          fetchedStatuses.add(status);
        }
      }

      // Add other users' statuses
      for (var doc in statusSnapshot.docs) {
        final status = doc.data() as Map<String, dynamic>;
        final statusUserId = status['userId'];

        if (statusUserId == currentUser.uid) continue;

        final statusUserDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(statusUserId)
            .get();

        status['userName'] = statusUserDoc.data()?['name'] ?? 'Unknown';
        status['userAvatar'] = statusUserDoc.data()?['avatar'] ?? '';
        status['id'] = doc.id;
        status['isMyStatus'] = false;
        fetchedStatuses.add(status);
      }

    setState(() {
        statuses.clear();
        statuses.addAll(fetchedStatuses);
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error loading statuses: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    final myStatuses = statuses.where((status) => status['isMyStatus'] == true).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Status'),
        actions: [
          IconButton(
            icon: const Icon(Icons.camera_alt_outlined),
            onPressed: () => _pickAndUploadStatus(),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Column(
        children: [
          // My Status Section
          InkWell(
            onTap: () {
              if (myStatuses.isNotEmpty) {
                final userStatuses = _getUserStatuses(myStatuses.first['userId']);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => StatusFullScreenView(
                      userStatuses: userStatuses,
                      initialIndex: 0,
                    ),
                  ),
                );
              } else {
                _pickAndUploadStatus();
              }
            },
            child: Container(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Stack(
                    children: [
                      if (myStatuses.isNotEmpty && myStatuses.first['mediaType'] == 'image')
                        CircleAvatar(
                          radius: 30,
                          backgroundImage: NetworkImage(myStatuses.first['mediaUrl']),
                        )
                      else if (myStatuses.isNotEmpty && myStatuses.first['mediaType'] == 'video')
                        CircleAvatar(
                                radius: 30,
                                backgroundColor: Colors.black26,
                                child: const Icon(Icons.play_circle_fill, color: Colors.white, size: 32),
                        )
                      else
                        FutureBuilder<DocumentSnapshot>(
                          future: FirebaseFirestore.instance
                              .collection('users')
                              .doc(FirebaseAuth.instance.currentUser?.uid)
                              .get(),
                          builder: (context, snapshot) {
                            final avatar = snapshot.data?.data() != null
                                ? (snapshot.data!.data() as Map<String, dynamic>)['avatar'] ?? ''
                                : '';
                            if (avatar != null && avatar.isNotEmpty) {
                              return CircleAvatar(
                                radius: 30,
                                backgroundImage: NetworkImage(avatar),
                              );
                            } else {
                              return const CircleAvatar(
                                radius: 30,
                                child: Icon(Icons.person, size: 30, color: Colors.grey),
                              );
                            }
                          },
                        ),
                      if (myStatuses.isEmpty)
                        Positioned(
                          right: 0,
                          bottom: 0,
                          child: Container(
                            padding: const EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              color: Theme.of(context).primaryColor,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.add,
                              color: Colors.white,
                              size: 20,
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: FutureBuilder<DocumentSnapshot>(
                      future: FirebaseFirestore.instance
                          .collection('users')
                          .doc(FirebaseAuth.instance.currentUser?.uid)
                          .get(),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return const SizedBox.shrink(); // Or a loading indicator
                        }
                        if (!snapshot.hasData || !snapshot.data!.exists) {
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'My Status',
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                myStatuses.isNotEmpty
                                    ? 'Tap to view your status'
                                    : 'Tap to add status update',
                                style: TextStyle(
                                  color: Colors.grey[600],
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          );
                        }

                        final userData = snapshot.data!.data() as Map<String, dynamic>?;
                        final currentUserName = userData?['name'] ??
                            (userData?['firstName'] != null && userData?['lastName'] != null
                                ? '${userData?['firstName']} ${userData?['lastName']}'.trim()
                                : 'Unknown');

                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              currentUserName,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              myStatuses.isNotEmpty
                                  ? 'Tap to view your status'
                                  : 'Tap to add status update',
                              style: TextStyle(
                                color: Colors.grey[600],
                                fontSize: 14,
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
          const Divider(height: 1),
          // Recent Updates Section
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            color: Colors.grey[100],
            child: const Row(
              children: [
                Text(
                  'Recent updates',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
          ),
          // Status List
          Expanded(
            child: statuses.isEmpty || statuses.length == myStatuses.length
                ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.photo_library_outlined,
                    size: 80,
                    color: Colors.grey[400],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'No status updates',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.grey[600],
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Be the first to share a status!',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey[500],
                    ),
                  ),
                ],
              ),
            )
                : ListView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: statuses.length,
              itemBuilder: (context, index) {
                final status = statuses[index];
                // Skip current user's status in the list as it's shown in My Status
                if (status['isMyStatus'] == true) {
                  return const SizedBox.shrink();
                }
                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => StatusFullScreenView(
                          userStatuses: _getUserStatuses(status['userId']),
                          initialIndex: 0,
                        ),
                      ),
                    );
                  },
                  child: AspectRatio(
                    aspectRatio: 9 / 16, // Assuming vertical video status
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8.0),
                      child: status['mediaType'] == 'image'
                          ? Image.network(
                              status['mediaUrl'],
                              fit: BoxFit.cover,
                              loadingBuilder: (context, child, loadingProgress) {
                                if (loadingProgress == null) return child;
                                return Center(
                                  child: CircularProgressIndicator(
                                    value: loadingProgress.expectedTotalBytes != null
                                        ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                                        : null,
                                  ),
                                );
                              },
                              errorBuilder: (context, error, stackTrace) => Icon(Icons.error),
                            )
                          : status['mediaType'] == 'video'
                              ? VideoPlayerWidget(videoUrl: status['mediaUrl'], isThumbnail: true)
                              : Container(),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _pickAndUploadStatus() async {
    try {
      // Show options for image or video
      final source = await showDialog<String>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Add Status'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.photo),
                title: const Text('Photo'),
                onTap: () => Navigator.pop(context, 'photo'),
              ),
              ListTile(
                leading: const Icon(Icons.videocam),
                title: const Text('Video'),
                onTap: () => Navigator.pop(context, 'video'),
              ),
            ],
          ),
        ),
      );

      if (source == null) return;

      // Show loading indicator
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Selecting media...'),
            duration: Duration(seconds: 1),
          ),
        );
      }

      final XFile? pickedFile = source == 'photo'
          ? await _imagePicker.pickImage(source: ImageSource.gallery)
          : await _imagePicker.pickVideo(source: ImageSource.gallery);

      if (pickedFile == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('No media selected'),
              backgroundColor: Colors.orange,
            ),
          );
        }
        return;
      }

      final isVideo = source == 'video';

      // Only check file existence and video duration on non-web platforms
      if (!kIsWeb) {
        final file = File(pickedFile.path);
        if (!await file.exists()) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Selected file does not exist'),
                backgroundColor: Colors.red,
              ),
            );
          }
          return;
        }
        if (isVideo) {
          final videoFile = File(pickedFile.path);
          final videoPlayerController = VideoPlayerController.file(videoFile);
          await videoPlayerController.initialize();
          final duration = videoPlayerController.value.duration;
          await videoPlayerController.dispose();

          if (duration.inSeconds > 30) {
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Video must be 30 seconds or less'),
                  backgroundColor: Colors.red,
                ),
              );
            }
            return;
          }
        }
      }

      setState(() {
        isLoading = true;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Uploading status...'),
            duration: Duration(seconds: 1),
          ),
        );
      }

      // Upload to Cloudinary using unsigned preset (web/mobile compatible)
      final uploadedUrl = await uploadToCloudinaryUnsigned(pickedFile, isVideo);
      if (uploadedUrl == null) {
        throw Exception('Failed to get upload URL from Cloudinary');
      }

      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser == null) {
        throw Exception('User not logged in');
      }

      // Save to Firestore
      await FirebaseFirestore.instance.collection('statuses').add({
        'userId': currentUser.uid,
        'mediaUrl': uploadedUrl,
        'mediaType': isVideo ? 'video' : 'image',
        'createdAt': FieldValue.serverTimestamp(),
        'viewedBy': [],
        'replies': [],
      });

      await _fetchStatuses();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Status uploaded successfully!'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      // Show error message to user
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error uploading status: \\${e.toString()}'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 5),
          ),
        );
      }
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> _markAsViewed(String statusId) async {
    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser == null) return;

      await FirebaseFirestore.instance
          .collection('statuses')
          .doc(statusId)
          .update({
        'viewedBy': FieldValue.arrayUnion([currentUser.uid]),
      });

      await _fetchStatuses();
    } catch (e) {
      print('Error marking status as viewed: $e');
    }
  }

  Widget _buildStatusTile(Map<String, dynamic> status) {
    final currentUser = FirebaseAuth.instance.currentUser;
    final isVideo = status['mediaType'] == 'video';
    final viewedBy = List<String>.from(status['viewedBy'] ?? []);
    final isViewed = currentUser != null && viewedBy.contains(currentUser.uid);
    final timeAgo = timeago.format(
      (status['createdAt'] as Timestamp).toDate(),
      locale: 'en_short',
    );

    return ListTile(
      onTap: () {
        final userStatuses = _getUserStatuses(status['userId']);
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => StatusFullScreenView(
              userStatuses: userStatuses,
              initialIndex: 0,
            ),
          ),
        );
        if (!isViewed && currentUser != null) {
          _markAsViewed(status['id']);
        }
      },
      leading: Container(
        width: 56,
        height: 56,
        padding: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(
            color: isViewed ? Colors.grey : Theme.of(context).primaryColor,
            width: 2,
          ),
        ),
        child: ClipOval(
          child: status['userAvatar'] != null && status['userAvatar'].isNotEmpty
              ? Image.network(
            status['userAvatar'],
            fit: BoxFit.cover,
          )
              : const Icon(Icons.person, size: 24),
        ),
      ),
      title: Text(
        status['userName'] ?? 'Unknown',
        style: const TextStyle(
          fontWeight: FontWeight.bold,
        ),
      ),
      subtitle: Text(
        timeAgo,
        style: TextStyle(
          color: Colors.grey[600],
          fontSize: 14,
        ),
      ),
    );
  }

  // Helper to get all statuses for a user
  List<Map<String, dynamic>> _getUserStatuses(String userId) {
    return statuses.where((status) => status['userId'] == userId).toList();
  }

  final TextEditingController _replyController = TextEditingController();

  Future<void> _deleteStatus(String statusId) async {
    try {
      setState(() {
        isLoading = true;
      });

      await FirebaseFirestore.instance
          .collection('statuses')
          .doc(statusId)
          .delete();

      await _fetchStatuses();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Status deleted successfully'),
            backgroundColor: Colors.green,
          ),
        );
      }

      setState(() {
        isFullScreen = false;
        selectedStatus = null;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error deleting status: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  // Helper function for unsigned upload supporting web and mobile
  Future<String?> uploadToCloudinaryUnsigned(XFile pickedFile, bool isVideo) async {
    final url = Uri.parse('https://api.cloudinary.com/v1_1/dkuyjynpe/${isVideo ? 'video' : 'image'}/upload');
    final request = http.MultipartRequest('POST', url)
      ..fields['upload_preset'] = 'statuses';

    if (kIsWeb) {
      // For web, use bytes
      Uint8List bytes = await pickedFile.readAsBytes();
      request.files.add(http.MultipartFile.fromBytes(
        'file',
        bytes,
        filename: pickedFile.name,
      ));
    } else {
      // For mobile/desktop, use file path
      request.files.add(await http.MultipartFile.fromPath('file', pickedFile.path));
    }

    final response = await request.send();

    if (response.statusCode == 200) {
      final respStr = await response.stream.bytesToString();
      final jsonResp = json.decode(respStr);
      return jsonResp['secure_url'];
    } else {
      print('Failed to upload: \\${response.statusCode}');
      return null;
    }
  }
}