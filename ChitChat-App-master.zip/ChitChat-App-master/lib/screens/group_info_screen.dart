import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class GroupInfoScreen extends StatefulWidget {
  final String groupId;

  const GroupInfoScreen({Key? key, required this.groupId}) : super(key: key);

  @override
  State<GroupInfoScreen> createState() => _GroupInfoScreenState();
}

class _GroupInfoScreenState extends State<GroupInfoScreen> {
  Map<String, dynamic>? groupData;
  bool isAdmin = false;
  bool isLoading = true;
  final user = FirebaseAuth.instance.currentUser;

  @override
  void initState() {
    super.initState();
    _fetchGroupData();
  }

  Future<void> _fetchGroupData() async {
    final doc = await FirebaseFirestore.instance.collection('groups').doc(widget.groupId).get();
    if (doc.exists) {
      setState(() {
        groupData = doc.data();
        isAdmin = groupData?['admins']?.contains(user?.uid) ?? false;
        isLoading = false;
      });
    }
  }

  Future<void> _removeMember(String memberId) async {
    if (!isAdmin) return;
    await FirebaseFirestore.instance.collection('groups').doc(widget.groupId).update({
      'members': FieldValue.arrayRemove([memberId]),
      'admins': FieldValue.arrayRemove([memberId]),
    });
    _fetchGroupData();
  }

  Future<void> _exitGroup() async {
    await FirebaseFirestore.instance.collection('groups').doc(widget.groupId).update({
      'members': FieldValue.arrayRemove([user?.uid]),
      'admins': FieldValue.arrayRemove([user?.uid]),
    });
    Navigator.pop(context);
  }

  Future<void> _deleteGroup() async {
    if (!isAdmin) return;
    await FirebaseFirestore.instance.collection('groups').doc(widget.groupId).delete();
    Navigator.pop(context);
  }

  Future<void> _updateGroupField(String field, dynamic value) async {
    await FirebaseFirestore.instance.collection('groups').doc(widget.groupId).update({field: value});
    _fetchGroupData();
  }

  Future<void> _editGroupName() async {
    final controller = TextEditingController(text: groupData?['name'] ?? '');
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Group Name'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(labelText: 'Group Name'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Save')),
        ],
      ),
    );
    if (result != null && result.isNotEmpty) {
      _updateGroupField('name', result);
    }
  }

  Future<void> _editGroupDescription() async {
    final controller = TextEditingController(text: groupData?['description'] ?? '');
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Description'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(labelText: 'Description'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Save')),
        ],
      ),
    );
    if (result != null) {
      _updateGroupField('description', result);
    }
  }

  Future<void> _editGroupAvatar() async {
    // TODO: Implement image picker and upload logic
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Avatar editing not implemented.')));
  }

  Future<void> _addMembers() async {
    // Fetch all contacts of the current user
    final contactsSnap = await FirebaseFirestore.instance
        .collection('users')
        .doc(user?.uid)
        .collection('contacts')
        .get();
    final currentMembers = Set<String>.from(groupData?['members'] ?? []);
    final contacts = contactsSnap.docs
        .map((doc) => doc.data())
        .where((c) => c['uid'] != null && !currentMembers.contains(c['uid']))
        .toList();
    final Set<String> selected = {};
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Members'),
        content: SizedBox(
          width: double.maxFinite,
          child: contacts.isEmpty
              ? const Text('No contacts to add.')
              : StatefulBuilder(
                  builder: (context, setState) => ListView.builder(
                    shrinkWrap: true,
                    itemCount: contacts.length,
                    itemBuilder: (context, index) {
                      final contact = contacts[index];
                      return CheckboxListTile(
                        value: selected.contains(contact['uid']),
                        onChanged: (val) {
                          setState(() {
                            if (val == true) {
                              selected.add(contact['uid']);
                            } else {
                              selected.remove(contact['uid']);
                            }
                          });
                        },
                        title: Text(contact['name'] ?? contact['email'] ?? ''),
                        secondary: contact['avatar'] != null && contact['avatar'].toString().isNotEmpty
                            ? CircleAvatar(backgroundImage: NetworkImage(contact['avatar']))
                            : CircleAvatar(child: Text((contact['name'] ?? '?')[0].toUpperCase())),
                      );
                    },
                  ),
                ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: selected.isEmpty
                ? null
                : () async {
                    await FirebaseFirestore.instance.collection('groups').doc(widget.groupId).update({
                      'members': FieldValue.arrayUnion(selected.toList()),
                    });
                    Navigator.pop(context);
                    _fetchGroupData();
                  },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading || groupData == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }
    final members = List<String>.from(groupData?['members'] ?? []);
    final admins = List<String>.from(groupData?['admins'] ?? []);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Group Info', style: TextStyle(fontFamily: 'Poppins')),
        backgroundColor: Colors.white,
        elevation: 1,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Center(
              child: GestureDetector(
                onTap: isAdmin ? _editGroupAvatar : null,
                child: CircleAvatar(
                  radius: 48,
                  backgroundColor: const Color(0xFF6C5CE7),
                  backgroundImage: (groupData?['avatar'] ?? '').isNotEmpty ? NetworkImage(groupData?['avatar']) : null,
                  child: (groupData?['avatar'] ?? '').isEmpty
                      ? const Icon(Icons.group, color: Colors.white, size: 40)
                      : null,
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              groupData?['name'] ?? '',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, fontFamily: 'Poppins'),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
            if (isAdmin)
              TextButton(
                onPressed: _editGroupName,
                child: const Text('Edit Name', style: TextStyle(color: Color(0xFF6C5CE7), fontFamily: 'Poppins')),
              ),
            const SizedBox(height: 8),
            Text(
              groupData?['description'] ?? '',
              style: const TextStyle(fontSize: 15, color: Colors.grey, fontFamily: 'Poppins'),
              overflow: TextOverflow.ellipsis,
              maxLines: 2,
            ),
            if (isAdmin)
              TextButton(
                onPressed: _editGroupDescription,
                child: const Text('Edit Description', style: TextStyle(color: Color(0xFF6C5CE7), fontFamily: 'Poppins')),
              ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Members', style: TextStyle(fontWeight: FontWeight.bold, fontFamily: 'Poppins', fontSize: 16)),
                if (isAdmin)
                  TextButton.icon(
                    onPressed: _addMembers,
                    icon: const Icon(Icons.person_add, color: Color(0xFF6C5CE7)),
                    label: const Text('Add', style: TextStyle(color: Color(0xFF6C5CE7), fontFamily: 'Poppins')),
                  ),
              ],
            ),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: members.length,
              itemBuilder: (context, index) {
                final memberId = members[index];
                return FutureBuilder<DocumentSnapshot>(
                  future: FirebaseFirestore.instance.collection('users').doc(memberId).get(),
                  builder: (context, snapshot) {
                    final userData = snapshot.data?.data() as Map<String, dynamic>?;
                    final firstName = userData?['firstName'] ?? '';
                    final lastName = userData?['lastName'] ?? '';
                    final displayName = [firstName, lastName].where((s) => s.isNotEmpty).join(' ').trim();
                    final fallbackName = userData?['name'] ?? '';
                    final email = userData?['email'] ?? '';
                    final name = displayName.isNotEmpty
                        ? displayName
                        : (fallbackName.isNotEmpty ? fallbackName : (email.isNotEmpty ? email : 'Unknown'));
                    final avatar = userData?['avatar'] ?? '';
                    final isMemberAdmin = admins.contains(memberId);
                    return ListTile(
                      leading: avatar.isNotEmpty
                          ? CircleAvatar(backgroundImage: NetworkImage(avatar))
                          : CircleAvatar(child: Text(name.isNotEmpty ? name[0].toUpperCase() : '?')),
                      title: Text(name, style: const TextStyle(fontFamily: 'Poppins')),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          if (isMemberAdmin)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: const Color(0xFF6C5CE7),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Text('Admin', style: TextStyle(color: Colors.white, fontSize: 12, fontFamily: 'Poppins')),
                            ),
                          if (isAdmin && memberId != user?.uid)
                            IconButton(
                              icon: const Icon(Icons.remove_circle, color: Colors.red),
                              onPressed: () => _removeMember(memberId),
                            ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
            const SizedBox(height: 32),
            if (isAdmin)
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _deleteGroup,
                  icon: const Icon(Icons.delete),
                  label: const Text('Delete Group'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    textStyle: const TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            if (!isAdmin)
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _exitGroup,
                  icon: const Icon(Icons.exit_to_app),
                  label: const Text('Exit Group'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.grey.shade800,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    textStyle: const TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.bold),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
} 