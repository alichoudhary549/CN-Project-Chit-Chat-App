import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'group_info_screen.dart';
import 'group_media_screen.dart';

class GroupChatRoomScreen extends StatefulWidget {
  final String groupId;
  final String groupName;
  final String groupAvatar;

  const GroupChatRoomScreen({
    Key? key,
    required this.groupId,
    required this.groupName,
    required this.groupAvatar,
  }) : super(key: key);

  @override
  State<GroupChatRoomScreen> createState() => _GroupChatRoomScreenState();
}

class _GroupChatRoomScreenState extends State<GroupChatRoomScreen> {
  final TextEditingController _textController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  bool _isSending = false;

  @override
  void dispose() {
    _textController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _sendMessage() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    final text = _textController.text.trim();
    if (text.isEmpty) return;
    setState(() => _isSending = true);
    try {
      await FirebaseFirestore.instance
          .collection('groups')
          .doc(widget.groupId)
          .collection('messages')
          .add({
        'authorId': user.uid,
        'authorName': user.displayName ?? '',
        'authorAvatar': user.photoURL ?? '',
        'text': text,
        'type': 'text',
        'createdAt': DateTime.now(),
      });
      _textController.clear();
      _scrollController.animateTo(
        0.0,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to send message: $e')),
      );
    } finally {
      setState(() => _isSending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 1,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            widget.groupAvatar.isNotEmpty
                ? CircleAvatar(
                    radius: 18,
                    backgroundImage: NetworkImage(widget.groupAvatar),
                  )
                : CircleAvatar(
                    radius: 18,
                    backgroundColor: const Color(0xFF6C5CE7),
                    child: Text(
                      widget.groupName.isNotEmpty ? widget.groupName[0].toUpperCase() : '?',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Poppins',
                      ),
                    ),
                  ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                widget.groupName,
                style: const TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Poppins',
                  fontSize: 16,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            IconButton(
              icon: const Icon(Icons.info_outline, color: Color(0xFF6C5CE7)),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => GroupInfoScreen(groupId: widget.groupId),
                  ),
                );
              },
            ),
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert, color: Color(0xFF6C5CE7)),
              onSelected: (value) async {
                switch (value) {
                  case 'info':
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => GroupInfoScreen(groupId: widget.groupId),
                      ),
                    );
                    break;
                  case 'media':
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => GroupMediaScreen(groupId: widget.groupId),
                      ),
                    );
                    break;
                  case 'mute':
                    showDialog(
                      context: context,
                      builder: (context) => const AlertDialog(
                        title: Text('Mute Notifications'),
                        content: Text('Feature coming soon!'),
                      ),
                    );
                    break;
                  case 'search':
                    showDialog(
                      context: context,
                      builder: (context) => const AlertDialog(
                        title: Text('Search'),
                        content: Text('Feature coming soon!'),
                      ),
                    );
                    break;
                  case 'clear':
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: const Text('Clear Chat'),
                        content: const Text('Are you sure you want to clear all messages in this group?'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
                          TextButton(
                            onPressed: () {
                              // TODO: Implement clear chat logic
                              Navigator.pop(context);
                              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Chat cleared (not implemented).')));
                            },
                            child: const Text('Clear'),
                          ),
                        ],
                      ),
                    );
                    break;
                  case 'report':
                    showDialog(
                      context: context,
                      builder: (context) => const AlertDialog(
                        title: Text('Report Group'),
                        content: Text('Feature coming soon!'),
                      ),
                    );
                    break;
                  case 'exit':
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: const Text('Exit Group'),
                        content: const Text('Are you sure you want to exit this group?'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
                          TextButton(
                            onPressed: () async {
                              // Remove user from group members
                              await FirebaseFirestore.instance.collection('groups').doc(widget.groupId).update({
                                'members': FieldValue.arrayRemove([FirebaseAuth.instance.currentUser?.uid]),
                                'admins': FieldValue.arrayRemove([FirebaseAuth.instance.currentUser?.uid]),
                              });
                              Navigator.pop(context);
                              Navigator.pop(context);
                            },
                            child: const Text('Exit'),
                          ),
                        ],
                      ),
                    );
                    break;
                }
              },
              itemBuilder: (context) => [
                const PopupMenuItem(value: 'info', child: Text('Group Info')),
                const PopupMenuItem(value: 'media', child: Text('Media, Links, and Docs')),
                const PopupMenuItem(value: 'mute', child: Text('Mute/Unmute Notifications')),
                const PopupMenuItem(value: 'search', child: Text('Search')),
                const PopupMenuItem(value: 'clear', child: Text('Clear Chat')),
                const PopupMenuItem(value: 'report', child: Text('Report Group')),
                const PopupMenuItem(value: 'exit', child: Text('Exit Group')),
              ],
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('groups')
                  .doc(widget.groupId)
                  .collection('messages')
                  .orderBy('createdAt', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(child: Text('Error loading messages'));
                }
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final messages = snapshot.data!.docs;
                if (messages.isEmpty) {
                  return Center(
                    child: Text(
                      'No messages yet. Start the conversation!',
                      style: TextStyle(
                        color: Colors.grey.shade600,
                        fontFamily: 'Poppins',
                      ),
                    ),
                  );
                }
                return ListView.builder(
                  controller: _scrollController,
                  reverse: true,
                  itemCount: messages.length,
                  itemBuilder: (context, index) {
                    final data = messages[index].data() as Map<String, dynamic>;
                    final isMe = data['authorId'] == FirebaseAuth.instance.currentUser?.uid;
                    return Align(
                      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: isMe ? const Color(0xFF6C5CE7) : Colors.grey.shade100,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (!isMe)
                              Row(
                                children: [
                                  data['authorAvatar'] != null && data['authorAvatar'].toString().isNotEmpty
                                      ? CircleAvatar(
                                          radius: 12,
                                          backgroundImage: NetworkImage(data['authorAvatar']),
                                        )
                                      : CircleAvatar(
                                          radius: 12,
                                          backgroundColor: const Color(0xFF6C5CE7),
                                          child: Text(
                                            data['authorName'] != null && data['authorName'].toString().isNotEmpty
                                                ? data['authorName'][0].toUpperCase()
                                                : '?',
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 12,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                  const SizedBox(width: 6),
                                  Text(
                                    data['authorName'] ?? '',
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Poppins',
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            if (!isMe) const SizedBox(height: 4),
                            Text(
                              data['text'] ?? '',
                              style: TextStyle(
                                color: isMe ? Colors.white : Colors.black,
                                fontFamily: 'Poppins',
                                fontSize: 15,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            color: Colors.white,
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.add, color: Color(0xFF6C5CE7)),
                  onPressed: () {
                    // TODO: Show attachment menu
                  },
                ),
                Expanded(
                  child: TextField(
                    controller: _textController,
                    decoration: const InputDecoration(
                      hintText: 'Type a message...',
                      border: InputBorder.none,
                    ),
                    onSubmitted: (text) => _sendMessage(),
                  ),
                ),
                IconButton(
                  icon: _isSending
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.send, color: Color(0xFF6C5CE7)),
                  onPressed: _isSending ? null : _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
} 