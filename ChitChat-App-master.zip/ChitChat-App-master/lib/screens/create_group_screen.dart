import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:typed_data';
import 'package:cloudinary_public/cloudinary_public.dart';

class CreateGroupScreen extends StatefulWidget {
  const CreateGroupScreen({super.key});

  @override
  State<CreateGroupScreen> createState() => _CreateGroupScreenState();
}

class _CreateGroupScreenState extends State<CreateGroupScreen> {
  final TextEditingController _nameController = TextEditingController();
  Uint8List? _avatarBytes;
  final List<Map<String, dynamic>> _contacts = [];
  final Set<String> _selectedContactIds = {};
  bool _isLoading = false;

  // Initialize CloudinaryPublic with your cloud name and upload preset
  // Replace 'YOUR_CLOUD_NAME' and 'YOUR_UNSIGNED_UPLOAD_PRESET' with your actual values
  final cloudinary = CloudinaryPublic(
    'dkuyjynpe', // Your Cloud Name
    'my_group_upload_preset', // Your unsigned upload preset
    cache: false,
  );

  @override
  void initState() {
    super.initState();
    _fetchContacts();
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  Future<void> _fetchContacts() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    final contactsSnap = await FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .collection('contacts')
        .get();
    setState(() {
      _contacts.clear();
      _contacts.addAll(contactsSnap.docs.map((doc) {
        final data = doc.data();
        return {
          'contactDocId': doc.id,
          'uid': data['uid'],
          'name': data['name'] ?? data['email'] ?? '',
          'avatar': data['avatar'] ?? '',
          'email': data['email'] ?? '',
          'isRegistered': data['isRegistered'] ?? false,
        };
      }));
    });
  }

  Future<void> _pickAvatar() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 70);
    if (picked != null) {
      final bytes = await picked.readAsBytes();
      setState(() {
        _avatarBytes = bytes;
      });
    }
  }

  void _createGroup() async {
    if (_nameController.text.trim().isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Group name cannot be empty')),
      );
      return;
    }
    if (_selectedContactIds.isEmpty) {
      if (!mounted) return;
       ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select at least one member')),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
       setState(() {
        _isLoading = false;
      });
      return;
    }

    // Add current user's UID to the members list
    final allMembers = _selectedContactIds.toList()..add(user.uid);

    String? finalAvatarUrl; // Variable to hold the final avatar URL

    try {
      // Upload avatar image if _avatarBytes is not null using cloudinary_public
      if (_avatarBytes != null) {
        // Convert Uint8List to ByteData
        ByteData byteData = ByteData.view(_avatarBytes!.buffer);
        CloudinaryResponse response = await cloudinary.uploadFile(
          await CloudinaryFile.fromFutureByteData(
            Future.value(byteData), // Provide the ByteData as a Future
            identifier: 'group_avatar_${DateTime.now().millisecondsSinceEpoch}', // Provide a unique identifier
            resourceType: CloudinaryResourceType.Image, // Use CloudinaryResourceType from cloudinary_public
          ),
        );
        finalAvatarUrl = response.secureUrl; // Get the secure URL
      }

      final newGroupDoc = await FirebaseFirestore.instance.collection('groups').add({
        'name': _nameController.text.trim(),
        'avatar': finalAvatarUrl, // Use the potentially uploaded avatar URL
        'createdAt': FieldValue.serverTimestamp(),
        'members': allMembers, // Store UIDs or contactDocIds?
        'admins': [user.uid], // Creator is the first admin
        'lastMessage': '',
        'lastMessageTimestamp': null,
        'unreadCount': 0, // This might need per-user handling
      });

      // Add members to a 'members' subcollection within the group document
      // This allows storing member-specific data like unread count, nicknames, etc.
      final batch = FirebaseFirestore.instance.batch();
      for (final memberId in allMembers) {
        batch.set(newGroupDoc.collection('members').doc(memberId), {
          'joinedAt': FieldValue.serverTimestamp(),
          // Add other member-specific fields here
        });
      }
      await batch.commit();


      setState(() {
        _isLoading = false;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Group created successfully!')),
        );
        Navigator.pop(context); // Close the creation screen
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to create group: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Create Group'),
        backgroundColor: const Color(0xFF6C5CE7),
        foregroundColor: Colors.white,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Center(
                    child: GestureDetector(
                      onTap: _pickAvatar,
                      child: CircleAvatar(
                        radius: 40,
                        backgroundColor: const Color(0xFF6C5CE7),
                        backgroundImage: _avatarBytes != null ? MemoryImage(_avatarBytes!) : null,
                        child: _avatarBytes == null
                            ? const Icon(Icons.camera_alt, color: Colors.white, size: 32)
                            : null,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _nameController,
                    decoration: const InputDecoration(
                      labelText: 'Group Name',
                      labelStyle: TextStyle(fontFamily: 'Poppins'),
                      border: OutlineInputBorder(),
                    ),
                    style: const TextStyle(fontFamily: 'Poppins'),
                  ),
                  const SizedBox(height: 24),
                  const Text(
                    'Add Members',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Poppins',
                    ),
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: _contacts.isEmpty
                        ? const Text('No contacts found.')
                        : ListView.builder(
                            itemCount: _contacts.length,
                            itemBuilder: (context, index) {
                              final contact = _contacts[index];
                              final contactIdToUse = contact['contactDocId'];
                              final isSelected = _selectedContactIds.contains(contactIdToUse);

                              return ListTile(
                                leading: contact['avatar'].isNotEmpty
                                    ? CircleAvatar(
                                        backgroundImage: NetworkImage(contact['avatar']),
                                      )
                                    : CircleAvatar(
                                        child: Text(
                                          contact['name'].isNotEmpty ? contact['name'][0].toUpperCase() : '?',
                                          style: const TextStyle(fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                title: Text(contact['name'], style: const TextStyle(fontFamily: 'Poppins')),
                                subtitle: Text(contact['email'], style: const TextStyle(fontFamily: 'Poppins', fontSize: 12)),
                                trailing: Checkbox(
                                  value: isSelected,
                                  onChanged: (val) {
                                    final selectedId = contact['contactDocId'];
                                    if (selectedId == null) {
                                      // This case should ideally not happen now, but good to keep the check
                                      return;
                                    }
                                    setState(() {
                                      if (val == true) {
                                        _selectedContactIds.add(selectedId);
                                      } else {
                                        _selectedContactIds.remove(selectedId);
                                      }
                                    });
                                  },
                                ),
                              );
                            },
                          ),
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _createGroup,
                      icon: const Icon(Icons.check),
                      label: const Text('Create Group'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF6C5CE7),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        textStyle: const TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
} 