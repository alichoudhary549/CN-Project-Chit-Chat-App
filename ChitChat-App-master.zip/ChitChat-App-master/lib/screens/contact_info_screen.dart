import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../widgets/avatar_widget.dart';
import 'call_screen.dart';

class ContactInfoScreen extends StatefulWidget {
  final String contactId;
  final String chatId;

  const ContactInfoScreen({
    super.key,
    required this.contactId,
    required this.chatId,
  });

  @override
  State<ContactInfoScreen> createState() => _ContactInfoScreenState();
}

class _ContactInfoScreenState extends State<ContactInfoScreen> {
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      return Scaffold(
        appBar: AppBar(title: Text('Contact Info')),
        body: const Center(child: Text('User not logged in')),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Contact Info'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit, color: Color(0xFF6C5CE7)),
            onPressed: () => _showEditContactDialog(context),
          ),
        ],
      ),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .doc(widget.contactId)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || !snapshot.data!.exists) {
            return const Center(child: Text('Contact not found'));
          }

          final userData = snapshot.data!.data() as Map<String, dynamic>?;
          final avatar = userData?['avatar'] ?? '';
          final firstName = userData?['firstName'] ?? '';
          final lastName = userData?['lastName'] ?? '';
          final email = userData?['email'] ?? '';
          final phone = userData?['phone'] ?? '';
          final displayName = [firstName, lastName].where((s) => s.isNotEmpty).join(' ').trim();
          final name = displayName.isNotEmpty ? displayName : (email.isNotEmpty ? email : 'Unknown');

          return SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 20),
                AvatarWidget(
                  avatarUrl: avatar,
                  name: name,
                  radius: 50,
                  showBorder: true,
                  borderColor: const Color(0xFF6C5CE7),
                ),
                const SizedBox(height: 16),
                Text(
                  name,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                if (phone.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: Text(
                      phone,
                      style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                    ),
                  ),
                if (email.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 4.0),
                    child: Text(
                      email,
                      style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                    ),
                  ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildActionButton(Icons.call, 'Call', () => this._startCall(context, isVideo: false)),
                    _buildActionButton(Icons.videocam, 'Video', () => this._startCall(context, isVideo: true)),
                  ],
                ),
                const SizedBox(height: 20),
                const Divider(),
                _buildMenuItem(Icons.image, 'Media, Links, and Docs', () => this._navigateToMedia()),
                _buildMenuItem(Icons.notifications_off_outlined, 'Mute Notifications', () => this._toggleMute()),
                _buildMenuItem(Icons.search, 'Search', () => this._showFeatureComingSoon('Search')),
                _buildMenuItem(Icons.cleaning_services_outlined, 'Clear Chat', () => _showClearChatDialog(context)),
                _buildMenuItem(Icons.flag_outlined, 'Report', () => this._showFeatureComingSoon('Report')),
                _buildMenuItem(Icons.block, 'Block/Unblock User', () => this._showFeatureComingSoon('Block/Unblock User')),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildActionButton(IconData icon, String label, VoidCallback onPressed) {
    return Column(
      children: [
        IconButton(
          icon: Icon(icon, color: const Color(0xFF6C5CE7), size: 28),
          onPressed: onPressed,
        ),
        Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[700])),
      ],
    );
  }

  Widget _buildMenuItem(IconData icon, String title, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: Colors.grey[700]),
      title: Text(title),
      onTap: onTap,
    );
  }

  void _showFeatureComingSoon(String feature) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$feature feature coming soon!')),
    );
  }

  void _navigateToMedia() {
    // TODO: Implement navigation to Media screen
    _showFeatureComingSoon('Media, Links, and Docs');
  }

  Future<void> _toggleMute() async {
    // TODO: Implement mute logic (similar to ChatRoomScreen)
    _showFeatureComingSoon('Mute Notifications');
  }

  void _showClearChatDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear Chat'),
        content: const Text('Are you sure you want to clear all messages in this chat?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              // TODO: Implement clear chat logic
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Chat cleared (not implemented).')));
            },
            child: const Text('Clear'),
          ),
        ],
      ),
    );
  }

  Future<void> _startCall(BuildContext context, {required bool isVideo}) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    if (!context.mounted) return;

    // Fetch contact's full name and avatar
    final contactDoc = await FirebaseFirestore.instance.collection('users').doc(widget.contactId).get();
    final contactData = contactDoc.data();
    final contactFirstName = contactData?['firstName'] ?? '';
    final contactLastName = contactData?['lastName'] ?? '';
    final contactFullName = [contactFirstName, contactLastName].where((s) => s.isNotEmpty).join(' ').trim();
    final contactDisplayName = contactData?['name'] ?? '';
    final contactEmail = contactData?['email'] ?? '';
    final nameToShow = contactFullName.isNotEmpty
        ? contactFullName
        : (contactDisplayName.isNotEmpty
            ? contactDisplayName
            : (contactEmail.isNotEmpty ? contactEmail : 'Unknown'));
    final contactAvatar = contactData?['avatar'] ?? '';

    final callDoc = FirebaseFirestore.instance.collection('calls').doc(widget.contactId);
    await callDoc.set({
      'callerId': user.uid,
      'callerName': user.displayName ?? user.email ?? 'Unknown',
      'calleeId': widget.contactId,
      'firstName': contactFirstName,
      'lastName': contactLastName,
      'name': nameToShow,
      'email': contactEmail,
      'avatar': contactAvatar,
      'type': isVideo ? 'video' : 'voice',
      'isVideo': isVideo,
      'status': 'ringing',
      'channel': widget.chatId,
      'token': null, // Use static or generate token if needed
      'timestamp': DateTime.now(),
    });

    // Navigate to CallScreen immediately for now. Ringtone and call state management will need to be handled.
    if (!context.mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CallScreen(
          isVideo: isVideo,
          channelName: widget.chatId,
          token: null,
          contactName: nameToShow,
          contactAvatar: contactAvatar,
        ),
      ),
    );
  }

  void _showEditContactDialog(BuildContext context) {
    final firstNameController = TextEditingController();
    final lastNameController = TextEditingController();
    final emailController = TextEditingController();
    final phoneController = TextEditingController();

    // Pre-fill the controllers with existing data
    FirebaseFirestore.instance
        .collection('users')
        .doc(widget.contactId)
        .get()
        .then((doc) {
      if (doc.exists) {
        final data = doc.data() as Map<String, dynamic>;
        firstNameController.text = data['firstName'] ?? '';
        lastNameController.text = data['lastName'] ?? '';
        emailController.text = data['email'] ?? '';
        phoneController.text = data['phone'] ?? '';
      }
    });

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Contact'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: firstNameController,
                decoration: const InputDecoration(
                  labelText: 'First Name',
                  prefixIcon: Icon(Icons.person),
                ),
                textCapitalization: TextCapitalization.words,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: lastNameController,
                decoration: const InputDecoration(
                  labelText: 'Last Name',
                  prefixIcon: Icon(Icons.person_outline),
                ),
                textCapitalization: TextCapitalization.words,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: emailController,
                decoration: const InputDecoration(
                  labelText: 'Email',
                  prefixIcon: Icon(Icons.email),
                ),
                keyboardType: TextInputType.emailAddress,
                enabled: false, // Email cannot be changed
              ),
              const SizedBox(height: 12),
              TextField(
                controller: phoneController,
                decoration: const InputDecoration(
                  labelText: 'Phone Number',
                  prefixIcon: Icon(Icons.phone),
                ),
                keyboardType: TextInputType.phone,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final firstName = firstNameController.text.trim();
              final lastName = lastNameController.text.trim();
              final phone = phoneController.text.trim();

              if (firstName.isEmpty || lastName.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('First and last name are required')),
                );
                return;
              }

              try {
                // Update the contact's user profile
                await FirebaseFirestore.instance
                    .collection('users')
                    .doc(widget.contactId)
                    .update({
                  'firstName': firstName,
                  'lastName': lastName,
                  'phone': phone,
                });

                // Update the contact in the current user's contacts
                final currentUser = FirebaseAuth.instance.currentUser;
                if (currentUser != null) {
                  await FirebaseFirestore.instance
                      .collection('users')
                      .doc(currentUser.uid)
                      .collection('contacts')
                      .doc(widget.contactId)
                      .update({
                    'firstName': firstName,
                    'lastName': lastName,
                    'phone': phone,
                  });
                }

                if (mounted) {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Contact updated successfully')),
                  );
                }
              } catch (e) {
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Failed to update contact')),
                  );
                }
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }
} 