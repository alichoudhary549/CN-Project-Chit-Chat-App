import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'create_group_screen.dart';
import 'group_chat_room_screen.dart';

class GroupsScreen extends StatefulWidget {
  const GroupsScreen({Key? key}) : super(key: key);

  @override
  State<GroupsScreen> createState() => _GroupsScreenState();
}

class _GroupsScreenState extends State<GroupsScreen> {
  final TextEditingController _searchController = TextEditingController();
  bool _isSearching = false;
  List<Map<String, dynamic>> _groupList = [];
  List<Map<String, dynamic>> _filteredGroupList = [];
  late Stream<QuerySnapshot> _groupsStream;

  @override
  void initState() {
    super.initState();
    _groupsStream = FirebaseFirestore.instance
        .collection('groups')
        .where('members', arrayContains: FirebaseAuth.instance.currentUser?.uid)
        .orderBy('lastMessageTimestamp', descending: true)
        .snapshots();
    _searchController.addListener(_filterGroups);
  }

  void _filterGroups() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _isSearching = query.isNotEmpty;
      _filteredGroupList = _groupList.where((group) {
        final groupName = group['name'].toLowerCase();
        final lastMessage = group['lastMessage'].toLowerCase();
        return groupName.contains(query) || lastMessage.contains(query);
      }).toList();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 1,
        title: _isSearching
            ? TextField(
                controller: _searchController,
                autofocus: true,
                decoration: InputDecoration(
                  hintText: "Search groups...",
                  border: InputBorder.none,
                  hintStyle: TextStyle(
                    color: Colors.grey.shade500,
                    fontSize: 18,
                    fontFamily: 'Poppins',
                  ),
                ),
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                  fontFamily: 'Poppins',
                ),
              )
            : const Text(
                "Groups",
                style: TextStyle(
                  color: Colors.black,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w600,
                ),
              ),
        actions: [
          IconButton(
            icon: Icon(
              _isSearching ? Icons.close : Icons.search,
              color: Colors.grey.shade700,
            ),
            onPressed: () {
              setState(() {
                if (_isSearching) {
                  _searchController.clear();
                }
                _isSearching = !_isSearching;
              });
            },
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _groupsStream,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            print('Groups Stream Error: \\${snapshot.error}');
            return Center(child: Text('Error loading groups: \\${snapshot.error}'));
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          _groupList = snapshot.data!.docs.map((doc) {
            final data = doc.data() as Map<String, dynamic>;
            return {
              'groupId': doc.id,
              'name': data['name'] ?? '',
              'avatar': data['avatar'] ?? '',
              'lastMessage': data['lastMessage'] ?? '',
              'lastMessageTimestamp': (data['lastMessageTimestamp'] as Timestamp?)?.toDate(),
              'unreadCount': data['unreadCount'] ?? 0,
              'members': data['members'] ?? [],
              'admins': data['admins'] ?? [],
            };
          }).toList();
          // Fallback: sort in Dart if needed
          _groupList.sort((a, b) {
            final aTime = a['lastMessageTimestamp'] as DateTime?;
            final bTime = b['lastMessageTimestamp'] as DateTime?;
            if (aTime == null && bTime == null) return 0;
            if (aTime == null) return 1;
            if (bTime == null) return -1;
            return bTime.compareTo(aTime);
          });
          final groupsToShow = _isSearching ? _filteredGroupList : _groupList;
          if (groupsToShow.isEmpty) {
            return Center(
              child: Text(
                "No Groups Yet",
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.grey.shade600,
                  fontFamily: 'Poppins',
                ),
              ),
            );
          }
          return ListView.builder(
            itemCount: groupsToShow.length,
            itemBuilder: (context, index) {
              final group = groupsToShow[index];
              final hasAvatar = group['avatar'] != null && group['avatar'].toString().isNotEmpty;
              final displayName = group['name'] ?? '';
              final timestamp = group['lastMessageTimestamp'] as DateTime?;
              final formattedTime = timestamp != null
                  ? "${timestamp.hour}:${timestamp.minute.toString().padLeft(2, '0')} ${timestamp.hour >= 12 ? 'PM' : 'AM'}"
                  : '';
              return ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                leading: hasAvatar
                    ? CircleAvatar(
                        radius: 25,
                        backgroundImage: NetworkImage(group['avatar']),
                        backgroundColor: const Color(0xFF6C5CE7),
                      )
                    : CircleAvatar(
                        radius: 25,
                        backgroundColor: const Color(0xFF6C5CE7),
                        child: Text(
                          (displayName.isNotEmpty ? displayName[0].toUpperCase() : '?'),
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Poppins',
                          ),
                        ),
                      ),
                title: Text(
                  displayName,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontFamily: 'Poppins',
                  ),
                ),
                subtitle: Row(
                  children: [
                    if (group['lastMessage'].isNotEmpty)
                      Expanded(
                        child: Text(
                          group['lastMessage'],
                          style: TextStyle(
                            color: Colors.grey.shade600,
                            fontFamily: 'Poppins',
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      )
                    else
                      Text(
                        'Tap to start chatting',
                        style: TextStyle(
                          color: Colors.grey.shade500,
                          fontStyle: FontStyle.italic,
                          fontFamily: 'Poppins',
                        ),
                      ),
                  ],
                ),
                trailing: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (group['lastMessage'].isNotEmpty && formattedTime.isNotEmpty)
                      Text(
                        formattedTime,
                        style: TextStyle(
                          color: Colors.grey.shade500,
                          fontSize: 12,
                          fontFamily: 'Poppins',
                        ),
                      ),
                    if (group['unreadCount'] > 0)
                      Container(
                        margin: const EdgeInsets.only(top: 4),
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const LinearGradient(
                            colors: [Color(0xFF6C5CE7), Color(0xFFA78BFA)],
                          ),
                        ),
                        child: Text(
                          "${group['unreadCount']}",
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontFamily: 'Poppins',
                          ),
                        ),
                      ),
                  ],
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => GroupChatRoomScreen(
                        groupId: group['groupId'],
                        groupName: group['name'],
                        groupAvatar: group['avatar'],
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const CreateGroupScreen()),
          );
          if (result != null) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Group created!')),
            );
            // Optionally, scroll to top or refresh
          }
        },
        backgroundColor: const Color(0xFF6C5CE7),
        child: const Icon(Icons.group_add, color: Colors.white),
      ),
    );
  }
} 