import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:video_player/video_player.dart';
import 'package:flutter/foundation.dart';
import 'dart:async';
import '../widgets/video_player_widget.dart';
import 'package:flutter_chat_types/flutter_chat_types.dart' as types;

class StatusFullScreenView extends StatefulWidget {
  final List<Map<String, dynamic>> userStatuses;
  final int initialIndex;

  const StatusFullScreenView({
    Key? key,
    required this.userStatuses,
    this.initialIndex = 0,
  }) : super(key: key);

  @override
  State<StatusFullScreenView> createState() => _StatusFullScreenViewState();
}

class _StatusFullScreenViewState extends State<StatusFullScreenView> {
  late PageController _pageController;
  late int _currentIndex;
  List<Map<String, dynamic>> _viewers = [];
  bool _loadingViewers = false;
  Timer? _autoCloseTimer;
  String? _currentUserId;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _pageController = PageController(initialPage: _currentIndex);
    _currentUserId = FirebaseAuth.instance.currentUser?.uid;
    _fetchViewers();
    _startAutoCloseTimer();
  }

  void _fetchViewers() async {
    final status = widget.userStatuses[_currentIndex];
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;
    if (status['userId'] != currentUser.uid) return;
    final viewedBy = List<String>.from(status['viewedBy'] ?? []);
    if (viewedBy.isEmpty) {
      setState(() => _viewers = []);
      return;
    }
    setState(() => _loadingViewers = true);
    final List<Map<String, dynamic>> viewers = [];
    for (final uid in viewedBy) {
      final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      if (doc.exists) {
        final data = doc.data()!;
        viewers.add({
          'name': (data['firstName'] != null && data['lastName'] != null && (data['firstName'] as String).isNotEmpty)
              ? ((data['firstName'] as String) + ' ' + (data['lastName'] as String)).trim()
              : (data['name'] ?? (data['email'] ?? 'Unknown')),
          'avatar': data['avatar'] ?? '',
        });
      }
    }
    setState(() {
      _viewers = viewers;
      _loadingViewers = false;
    });
  }

  void _showViewersSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        if (_loadingViewers) {
          return const SizedBox(
            height: 120,
            child: Center(child: CircularProgressIndicator()),
          );
        }
        if (_viewers.isEmpty) {
          return const SizedBox(
            height: 120,
            child: Center(child: Text('No one has viewed your status yet.')),
          );
        }
        return SizedBox(
          height: 300,
          child: ListView.builder(
            itemCount: _viewers.length,
            itemBuilder: (context, index) {
              final viewer = _viewers[index];
              return ListTile(
                leading: viewer['avatar'] != null && viewer['avatar'].isNotEmpty
                    ? CircleAvatar(backgroundImage: NetworkImage(viewer['avatar']))
                    : const CircleAvatar(child: Icon(Icons.person)),
                title: Text(viewer['name']),
              );
            },
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _pageController.dispose();
    _autoCloseTimer?.cancel();
    super.dispose();
  }

  void _startAutoCloseTimer() {
    _autoCloseTimer?.cancel();
    final status = widget.userStatuses[_currentIndex];
    final isImage = status['mediaType'] == 'image';
    if (isImage) {
      _autoCloseTimer = Timer(const Duration(seconds: 15), () {
        if (mounted) Navigator.pop(context);
      });
    }
  }

  void _onPageChanged(int index) {
    setState(() {
      _currentIndex = index;
      _fetchViewers();
      _startAutoCloseTimer();
    });
  }

  @override
  Widget build(BuildContext context) {
    final userStatuses = widget.userStatuses;
    final status = userStatuses[_currentIndex];
    final currentUser = FirebaseAuth.instance.currentUser;
    final isMyStatus = currentUser != null && status['userId'] == currentUser.uid;
    final isImage = status['mediaType'] == 'image';
    final isVideo = status['mediaType'] == 'video';

    // Construct a basic CustomMessage for VideoPlayerWidget
    final videoMessage = types.CustomMessage(
      id: status['id'] ?? '',
      author: types.User(id: status['userId'] ?? ''),
      createdAt: (status['createdAt'] as Timestamp?)?.millisecondsSinceEpoch ?? 0,
      metadata: {
        'messageType': 'video',
        'uri': status['mediaUrl'] ?? '',
        'name': status['mediaUrl']?.split('/').last ?? 'video.mp4',
        'size': 0,
      },
      type: types.MessageType.custom,
    );

    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      body: Stack(
        children: [
          PageView.builder(
            controller: _pageController,
            itemCount: userStatuses.length,
            onPageChanged: _onPageChanged,
            itemBuilder: (context, index) {
              final status = userStatuses[index];
              final isVideo = status['mediaType'] == 'video';

              return Center(
                child: isVideo
                    ? VideoPlayerWidget(
                        videoUrl: status['mediaUrl'] ?? '',
                        isThumbnail: false,
                        message: videoMessage,
                        currentUserId: _currentUserId ?? '',
                      )
                    : Image.network(
                        status['mediaUrl'],
                        fit: BoxFit.contain,
                        width: double.infinity,
                        height: double.infinity,
                      ),
              );
            },
          ),
          // Top bar with avatar, name, time, close button
          Positioned(
            top: 40,
            left: 16,
            right: 16,
            child: Row(
              children: [
                if (isMyStatus)
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.black26,
                    child: Icon(Icons.play_circle_fill, color: Colors.white, size: 32),
                  )
                else
                  CircleAvatar(
                    radius: 20,
                    backgroundImage: status['userAvatar'] != null && status['userAvatar'].isNotEmpty
                        ? NetworkImage(status['userAvatar'])
                        : null,
                    child: status['userAvatar'] == null || status['userAvatar'].isEmpty
                        ? const Icon(Icons.person, size: 20, color: Colors.white)
                        : null,
                  ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      status['userName'] ?? 'Unknown',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      timeago.format((status['createdAt'] as Timestamp).toDate(), locale: 'en_short'),
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                if (isMyStatus)
                  IconButton(
                    icon: const Icon(Icons.delete, color: Colors.redAccent),
                    tooltip: 'Delete Status',
                    onPressed: () async {
                      final confirm = await showDialog<bool>(
                        context: context,
                        builder: (context) => AlertDialog(
                          title: const Text('Delete Status'),
                          content: const Text('Are you sure you want to delete this status?'),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context, false),
                              child: const Text('Cancel'),
                            ),
                            TextButton(
                              onPressed: () => Navigator.pop(context, true),
                              child: const Text('Delete', style: TextStyle(color: Colors.red)),
                            ),
                          ],
                        ),
                      );
                      if (confirm == true) {
                        await FirebaseFirestore.instance
                            .collection('statuses')
                            .doc(status['id'])
                            .delete();
                        if (mounted) {
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Status deleted'),
                              backgroundColor: Colors.green,
                            ),
                          );
                        }
                      }
                    },
                  ),
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.white),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
          ),
          // Bottom bar with seen by indicator (eye icon)
          if (isMyStatus)
            Positioned(
              bottom: 32,
              left: 0,
              right: 0,
              child: Center(
                child: GestureDetector(
                  onTap: _showViewersSheet,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.remove_red_eye, color: Colors.white),
                        const SizedBox(width: 8),
                        Text(
                          _viewers.isNotEmpty ? '${_viewers.length} viewed' : 'No views yet',
                          style: const TextStyle(color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// You can use your existing _VideoPlayer widget here
class _VideoPlayer extends StatelessWidget {
  final String videoUrl;
  const _VideoPlayer({required this.videoUrl});
  @override
  Widget build(BuildContext context) {
    // Use your existing video player logic
    return Container(); // Replace with your video player
  }
}
