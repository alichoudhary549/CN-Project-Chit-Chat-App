import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    } else if (defaultTargetPlatform == TargetPlatform.android) {
      return android;
    }
    throw UnsupportedError(
      'DefaultFirebaseOptions are not supported for this platform.',
    );
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyBt6wx8h-8EL8xFfVIPclnEAXGBBqE0ra0',
    appId: '1:495226110888:web:763d036444ef5b4a1c939d',
    messagingSenderId: '495226110888',
    projectId: 'chitchat-830de',
    authDomain: 'chitchat-830de.firebaseapp.com',
    storageBucket: 'chitchat-830de.firebasestorage.app',
    measurementId: 'G-4845SYH6BD',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAkLP9i-oJ5a7Ck7Q4oO9T26FXVD2Sa7FA',
    appId: '1:495226110888:android:3026159f3aebb8cf1c939d',
    messagingSenderId: '495226110888',
    projectId: 'chitchat-830de',
    storageBucket: 'chitchat-830de.firebasestorage.app',
  );
} 