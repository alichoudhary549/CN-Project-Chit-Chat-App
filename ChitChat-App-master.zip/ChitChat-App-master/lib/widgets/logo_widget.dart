import 'package:flutter/material.dart';

class ChatLogo extends StatelessWidget {
  final double size;

  const ChatLogo({Key? key, this.size = 100}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Image.asset(
        'assets/images/logo1.png', // Updated image path for in-app logo
        fit: BoxFit.contain,
      ),
    );
  }
}

class FullLogo extends StatelessWidget {
  final double logoSize;
  final double textSize;
  final Color textColor;

  const FullLogo({
    super.key,
    this.logoSize = 60.0,
    this.textSize = 24.0,
    this.textColor = Colors.black,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        ChatLogo(size: logoSize),
        SizedBox(width: 12),
        Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            RichText(
              text: TextSpan(
                style: TextStyle(
                  fontSize: textSize,
                  fontFamily: 'Poppins',
                  color: textColor,
                  height: 0.9,
                ),
                children: [
                  TextSpan(
                    text: "Chit ",
                    style: TextStyle(fontWeight: FontWeight.normal),
                  ),
                  TextSpan(
                    text: "Chat",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            SizedBox(height: 4),
            Container(
              width: textSize * 3.5,
              height: 4,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(2),
                gradient: LinearGradient(
                  colors: [Colors.purple.shade400, Colors.blue.shade400],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}