import 'dart:async';
import 'dart:io'; // Import File
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:flutter_chat_types/flutter_chat_types.dart' as types; // Import flutter_chat_types
import 'package:path_provider/path_provider.dart'; // Import path_provider
import 'package:http/http.dart' as http; // Import http
import 'package:crypto/crypto.dart'; // Import crypto for hashing
import 'dart:convert'; // Import convert for utf8

class VideoPlayerWidget extends StatefulWidget {
  final String videoUrl;
  final bool isThumbnail;
  final int? messageWidth;
  final types.CustomMessage? message;
  final String? currentUserId;

  const VideoPlayerWidget({
    Key? key,
    required this.videoUrl,
    this.isThumbnail = false,
    this.messageWidth,
    this.message,
    this.currentUserId,
  }) : super(key: key);

  @override
  State<VideoPlayerWidget> createState() => _VideoPlayerWidgetState();
}

class _VideoPlayerWidgetState extends State<VideoPlayerWidget> {
  late VideoPlayerController _controller;
  bool _isInitialized = false;
  bool _showControls = false;
  Timer? _controlsTimer;
  bool _isDownloading = false;
  String? _localFilePath;
  bool _needsDownload = false; // Track if download is needed

  @override
  void initState() {
    super.initState();
    _checkAndHandleVideo(); // Renamed method for clarity
  }

  // Generate a unique local file name based on the video URL or message ID
  String _getLocalFileName(String url, String? messageId) {
     if (messageId != null && messageId.isNotEmpty) {
       return 'video_${messageId}.mp4';
     } else {
      // Use a hash of the URL as a fallback
      final bytes = utf8.encode(url);
      final digest = sha256.convert(bytes); // Corrected hashing
      return 'video_${digest.toString()}.mp4'; // Hex encoding via toString
     }
  }

  Future<void> _checkAndHandleVideo() async {
    print('VideoPlayerWidget received URL: ${widget.videoUrl}');

    if (widget.isThumbnail) {
      // For thumbnails, initialize controller to get properties but don't download/autoplay
      _initializeController(widget.videoUrl);
    } else {
      // For full view, check for local file or show download UI
      _localFilePath = await _getDownloadFilePath();

      if (await File(_localFilePath!).exists()) {
        // Local file exists, initialize controller with local file
        print('Local file found: $_localFilePath');
        _initializeController(_localFilePath!, isLocal: true, autoplay: false); // No autoplay
      } else if (widget.message != null && widget.currentUserId != null && widget.message!.author.id != widget.currentUserId) {
        // Received from another user and local file not found, show download UI
        print('Local file not found for received video. Showing download UI.');
        if (mounted) {
          setState(() {
            _isInitialized = false;
            _isDownloading = false;
            _needsDownload = true;
          });
        }
      } else {
        // Sent by current user or not enough info, play directly from URL (no download needed)
        print('Video from current user or no download needed. Initializing from URL.');
        _initializeController(widget.videoUrl, autoplay: false); // No autoplay initially
      }
    }
  }

  Future<String> _getDownloadFilePath() async {
      final dir = await getApplicationDocumentsDirectory();
      final fileName = _getLocalFileName(widget.videoUrl, widget.message?.id);
      return '${dir.path}/$fileName';
  }

  void _initializeController(String uri, {bool isLocal = false, bool autoplay = false}) {
     _controller = isLocal
        ? VideoPlayerController.file(File(uri))
        : VideoPlayerController.networkUrl(Uri.parse(uri));

    _controller.initialize().then((_) {
      if (mounted) {
        setState(() {
          _isInitialized = true;
          // Only autoplay if explicitly requested (not for initial load of received videos)
          if (autoplay) {
             _controller.play();
             _showControls = true;
             _startControlsTimer();
          }
        });
      }
    }).catchError((error) {
       print('Error initializing video controller: $error');
       if (mounted) {
         setState(() {
           _isInitialized = false;
           // Optionally show an error message to the user
         });
       }
    });

    if (!widget.isThumbnail) { // Add listener for playback state changes (for controls visibility)
      _controller.addListener(() {
        if (_controller.value.isPlaying && !_showControls) {
          setState(() {
            _showControls = true;
          });
          _startControlsTimer();
        } else if (!_controller.value.isPlaying && _showControls && _controller.value.duration == _controller.value.position) {
            // Hide controls when video finishes playing
             setState(() {
               _showControls = false;
             });
        }
      });
    }
  }

  Future<void> _downloadVideo() async {
    if (mounted) {
      setState(() {
        _isDownloading = true;
        _needsDownload = false; // Hide download button
      });
    }

    try {
      final response = await http.get(Uri.parse(widget.videoUrl));
      if (response.statusCode == 200) {
        final file = File(_localFilePath!);
        await file.writeAsBytes(response.bodyBytes);
        print('Video downloaded successfully to $_localFilePath');
        if (mounted) {
           setState(() {
             _isDownloading = false;
             _initializeController(_localFilePath!, isLocal: true, autoplay: false); // No autoplay after manual download
           });
        }
      } else {
        print('Failed to download video: ${response.statusCode}');
         if (mounted) {
           setState(() {
             _isDownloading = false;
             _needsDownload = true; // Show download button again on failure
             // Optionally show an error message to the user
           });
         }
      }
    } catch (e) {
      print('Error during video download: $e');
       if (mounted) {
         setState(() {
           _isDownloading = false;
           _needsDownload = true; // Show download button again on failure
            // Optionally show an error message to the user
         });
       }
    }
  }

  void _startControlsTimer() {
    _controlsTimer?.cancel();
    _controlsTimer = Timer(const Duration(seconds: 3), () {
      if (mounted && _controller.value.isPlaying) {
        setState(() {
          _showControls = false;
        });
      }
    });
  }

  @override
  void dispose() {
    if (_isInitialized) {
       _controller.dispose();
    }
    _controlsTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.isThumbnail) {
      // Thumbnail view: show placeholder with play icon
      return Stack(
           alignment: Alignment.center,
           children: [
              _isInitialized ? AspectRatio(
                 aspectRatio: _controller.value.aspectRatio,
                 child: VideoPlayer(_controller),
              ) : Container(color: Colors.black),
              CircleAvatar(
                radius: 24,
                backgroundColor: const Color.fromRGBO(0, 0, 0, 0.54), // Fixed deprecated withOpacity
                child: const Icon(Icons.play_arrow, color: Colors.white, size: 32),
              ),
           ]
        );
    }

    // Full-screen view
    if (_isDownloading) {
       return const Center(child: CircularProgressIndicator());
    }

    if (_needsDownload) {
       // Show download button if download is needed
       return Center(
         child: IconButton(
           icon: Icon(Icons.download, size: 48, color: Theme.of(context).primaryColor),
           onPressed: _downloadVideo,
         ),
       );
    }

    if (!_isInitialized) {
       // Show a placeholder or loading for initialization
       return const Center(child: CircularProgressIndicator()); // Or a black container, etc.
    }

    // Show video player if initialized (now with tap to play/pause)
    Widget videoWidget = AspectRatio(
      aspectRatio: _controller.value.aspectRatio,
      child: VideoPlayer(_controller),
    );

    if (widget.messageWidth != null) {
      videoWidget = SizedBox(
        width: widget.messageWidth!.toDouble(),
        child: videoWidget,
      );
    }

    return GestureDetector(
      onTap: () {
        if (_controller.value.isPlaying) {
          _controller.pause();
        } else {
          _controller.play();
          _startControlsTimer(); // Restart timer on play
        }
        setState(() {
           _showControls = !_controller.value.isPlaying; // Show controls if paused, hide if playing
        });
      },
      child: Stack(
        fit: widget.messageWidth != null ? StackFit.loose : StackFit.expand,
        children: [
          videoWidget,
          if (!_controller.value.isPlaying && _isInitialized) // Show play icon if paused and initialized
             Center(
               child: Icon(
                 Icons.play_arrow,
                 color: Colors.white, size: 72, // Larger play icon
               ),
             ),
          if (_showControls)
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color.fromRGBO(0, 0, 0, 0.3), // Fixed deprecated withOpacity
                    Colors.transparent,
                    Colors.transparent,
                    Color.fromRGBO(0, 0, 0, 0.3), // Fixed deprecated withOpacity
                  ],
                ),
              ),
            ),
          if (_showControls)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    IconButton(
                      icon: Icon(
                        _controller.value.isPlaying ? Icons.pause : Icons.play_arrow,
                        color: Colors.white,
                        size: 36,
                      ),
                      onPressed: () {
                        setState(() {
                          if (_controller.value.isPlaying) {
                            _controller.pause();
                          } else {
                            _controller.play();
                          }
                        });
                        _startControlsTimer();
                      },
                    ),
                    Expanded(
                      child: VideoProgressIndicator(
                        _controller,
                        allowScrubbing: true,
                        colors: const VideoProgressColors(
                          playedColor: Colors.white,
                          bufferedColor: Colors.white54,
                          backgroundColor: Colors.white24,
                        ),
                      ),
                    ),
                    Text(
                      '${_controller.value.position.inMinutes}:${(_controller.value.position.inSeconds % 60).toString().padLeft(2, '0')}',
                      style: const TextStyle(color: Colors.white),
                    ),
                    const SizedBox(width: 8),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
} 