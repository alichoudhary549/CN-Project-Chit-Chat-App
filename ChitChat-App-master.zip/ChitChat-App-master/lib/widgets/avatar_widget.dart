import 'package:flutter/material.dart';

class AvatarWidget extends StatelessWidget {
  final String? avatarUrl;
  final String? name;
  final double radius;
  final Color backgroundColor;
  final bool showBorder;
  final Color borderColor;
  final double borderWidth;
  final VoidCallback? onTap;
  final Widget? fallbackIcon;

  const AvatarWidget({
    Key? key,
    this.avatarUrl,
    this.name,
    this.radius = 25,
    this.backgroundColor = const Color(0xFF6C5CE7),
    this.showBorder = false,
    this.borderColor = Colors.white,
    this.borderWidth = 2,
    this.onTap,
    this.fallbackIcon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final displayName = name?.trim() ?? '';
    final hasValidAvatar = avatarUrl != null && avatarUrl!.isNotEmpty;

    Widget avatarContent = hasValidAvatar
        ? ClipOval(
            child: Image.network(
              avatarUrl!,
              width: radius * 2,
              height: radius * 2,
              fit: BoxFit.cover,
              loadingBuilder: (context, child, loadingProgress) {
                if (loadingProgress == null) return child;
                return Center(
                  child: CircularProgressIndicator(
                    value: loadingProgress.expectedTotalBytes != null
                        ? loadingProgress.cumulativeBytesLoaded /
                            loadingProgress.expectedTotalBytes!
                        : null,
                    valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
                  ),
                );
              },
              errorBuilder: (context, error, stackTrace) {
                print('Avatar loading error: $error');
                return _buildFallbackContent(displayName);
              },
            ),
          )
        : _buildFallbackContent(displayName);

    if (onTap != null) {
      avatarContent = GestureDetector(
        onTap: onTap,
        child: avatarContent,
      );
    }

    return Container(
      decoration: showBorder
          ? BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: borderColor,
                width: borderWidth,
              ),
            )
          : null,
      child: CircleAvatar(
        radius: radius,
        backgroundColor: backgroundColor,
        child: avatarContent,
      ),
    );
  }

  Widget _buildFallbackContent(String displayName) {
    if (fallbackIcon != null) {
      return fallbackIcon!;
    }
    
    if (displayName.isNotEmpty) {
      return Text(
        displayName[0].toUpperCase(),
        style: const TextStyle(
          color: Colors.white,
          fontSize: 16,
          fontWeight: FontWeight.bold,
          fontFamily: 'Poppins',
        ),
      );
    }
    
    return const Icon(
      Icons.person,
      color: Colors.white,
      size: 24,
    );
  }
} 