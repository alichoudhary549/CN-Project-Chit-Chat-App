import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

class FirebaseConfig {
  static Future<void> initializeFirebase() async {
    try {
      await Firebase.initializeApp(
        options: const FirebaseOptions(
          apiKey: 'YOUR-API-KEY',  // Replace with your Firebase API key
          appId: 'YOUR-APP-ID',    // Replace with your Firebase App ID
          messagingSenderId: 'YOUR-SENDER-ID', // Replace with your Sender ID
          projectId: 'YOUR-PROJECT-ID', // Replace with your Project ID
          storageBucket: 'YOUR-STORAGE-BUCKET', // Replace with your Storage Bucket
        ),
      );
    } catch (e) {
      if (kDebugMode) {
        print('Error initializing Firebase: $e');
      }
    }
  }
} 