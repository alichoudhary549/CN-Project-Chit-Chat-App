import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';

Future<void> main() async {
  // Initialize Firebase (only needed for Dart console app)
  await Firebase.initializeApp();

  final usersRef = FirebaseFirestore.instance.collection('users');
  final users = await usersRef.get();

  for (final doc in users.docs) {
    final data = doc.data();
    String? name = data['name'];
    name ??= data['displayName'];
    name ??= data['email'];
    if (name == null || name.trim().isEmpty) continue;

    final parts = name.trim().split(' ');
    final firstName = parts.isNotEmpty ? parts.first : '';
    final lastName = parts.length > 1 ? parts.sublist(1).join(' ') : '';

    print('Updating \\${doc.id}: firstName=\\$firstName, lastName=\\$lastName');

    await usersRef.doc(doc.id).update({
      'firstName': firstName,
      'lastName': lastName,
    });
  }

  for (final userDoc in users.docs) {
    final chatsRef = userDoc.reference.collection('chats');
    final chats = await chatsRef.get();
    for (final chatDoc in chats.docs) {
      final data = chatDoc.data();
      final contactId = data['contactId'];
      if (contactId == null) continue;
      // Fetch the contact's user profile
      final contactProfile = await usersRef.doc(contactId).get();
      final contactData = contactProfile.data();
      if (contactData == null) continue;
      final firstName = contactData['firstName'] ?? '';
      final lastName = contactData['lastName'] ?? '';
      if (firstName.isEmpty && lastName.isEmpty) continue;
      await chatDoc.reference.set({
        'firstName': firstName,
        'lastName': lastName,
      }, SetOptions(merge: true));
    }
  }

  print('All users updated!');
  print('All chats updated with real names!');
} 